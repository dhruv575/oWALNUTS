from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H));import bank_transport as t
r=H.parents[1]/'STUDIES/options_flow_v1/artifacts/posterior-reference-bank-v1/analysis-v2'
roles=dict(intent=r/'intent.json',bank=r/'analysis-output/bank-result.json',status=r/'analysis-output-status.json',audit=r/'independent-analysis-audit-v2.json',analysis=r/'analysis-output/analysis-result.json',audit_provenance=r/'independent-analysis-provenance-v2.json',analysis_plan=r/'analysis-plan.json',grid=r/'analysis-output/common-grid.json',manifest=r/'admission-manifest.json')
pin={k:str(v.resolve()) for k,v in roles.items()};pin['bindings']={str(v.resolve()):t.sha(v) for v in roles.values()};pin['target_sha256']=t.read(pin['bank'])['target_sha256']
assert json.loads((H/'actual-bank-pin.json').read_text())==pin
result=t.transport(pin,target_sha256=pin['target_sha256'],endpoints=t.FAMILY,indices=[0,123,29999]);result['bank_vectors']=len(result['bank_vectors'])
with (H/'actual-bank-transport-smoke.json').open('x') as f:json.dump(result,f,indent=2)
print('Three actual joint vectors transported; no candidate inference')
