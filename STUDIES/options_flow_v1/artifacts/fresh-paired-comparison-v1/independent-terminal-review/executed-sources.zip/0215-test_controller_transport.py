import copy
from pathlib import Path
import pytest
from controller_transport import terminal_to_arms,endpoint_values
from bank_transport import FAMILY

def lifecycle():
 cells=[];out=[];pairs=[]
 for i in range(36):
  pair={'id':f'p{i}'}
  for j,arm in enumerate(['public','reference']):
   cid=f'{arm}{i}';pair[arm]=cid;cell=dict(id=cid,backend=arm,sampler_seed=100+2*i+j,initialization_seed=1000+i,prediction_seed=130100+2*i+j);cells.append(cell)
   norm=dict(id=cid,outcome='usable',streams={k:cell[k] for k in ['sampler_seed','initialization_seed','prediction_seed']},endpoints={n:dict(estimate=1.,mcse=.01,probability=v['probability'],scale='native',distribution_id=v['distribution_id']) for n,v in FAMILY.items()})
   out.append(dict(controller=dict(id=cid,status='completed'),normalized=norm,full_cell_seconds=1.,worker_wrapper_and_preflight_seconds=.8,postprocessing_seconds=.2))
  pairs.append(pair)
 plan=dict(cells=cells);term=dict(expected=72,outcomes=out,budget_status='within_admission_budget');cost=dict(total_seconds_including_terminal_serialization=144.,total_budget_unresolved=False)
 lookup={r['controller']['id']:r['normalized'] for r in out};return plan,term,cost,pairs,lambda c:lookup[c['id']]

def test_complete_terminal_cost_and_pair_transport():
 args=lifecycle();arms,cost=terminal_to_arms(*args)
 assert sum(r['seconds'] for a in arms.values() for r in a)==144
 assert len(arms['public'])==len(arms['reference'])==36 and cost['shared_overhead_seconds']==72

def test_unattempted_and_global_budget_propagate():
 p,t,c,pairs,n=lifecycle();t['outcomes'][0]['controller']['status']='unattempted_budget';c['total_budget_unresolved']=True
 arms,cost=terminal_to_arms(p,t,c,pairs,n)
 assert arms['public'][0]['status']=='unstarted' and not arms['public'][0]['usable'] and len(cost['unresolved_reasons'])==2

def test_missing_duplicate_and_changed_normalization_fail():
 p,t,c,pairs,n=lifecycle();t['outcomes'].pop()
 with pytest.raises(ValueError):terminal_to_arms(p,t,c,pairs,n)
 p,t,c,pairs,n=lifecycle()
 with pytest.raises(ValueError):terminal_to_arms(p,t,c,pairs,lambda x:{})
 c['total_seconds_including_terminal_serialization']=1
 with pytest.raises(ValueError):terminal_to_arms(p,t,c,pairs,n)


def test_actual_endpoint_schema_and_wrong_scale():
 p,t,c,pairs,n=lifecycle();arms,_=terminal_to_arms(p,t,c,pairs,n)
 assert all(v==1. for v in arms['public'][0]['endpoints'].values())
 rows=t['outcomes'][0]['normalized']['endpoints'];rows[next(iter(rows))]['scale']='log'
 with pytest.raises(ValueError):endpoint_values(rows)

def test_unknown_status_fails_closed():
 p,t,c,pairs,n=lifecycle();t['outcomes'][0]['controller']['status']='mystery'
 with pytest.raises(ValueError):terminal_to_arms(p,t,c,pairs,n)


def test_production_dispatch_reconstructs_pinned_artifact_spec(tmp_path,monkeypatch):
 import json,types,sys
 from controller_transport import verified_normalizer
 from bank_transport import sha
 cell=dict(id='fit',backend='public',worker_directory=str(tmp_path/'worker'))
 (tmp_path/'worker').mkdir()
 for key in ('fixture','controller_status','bank_plan','pilot_plan','analysis_intent','report','hardware'):
  path=tmp_path/(key+'.json');path.write_text('{}');cell[key]=str(path)
 raw=tmp_path/'worker'/'draws-1000.json';raw.write_text('{}')
 plan=tmp_path/'plan.json';plan.write_text('{}')
 hashes={str(Path(x).resolve()):sha(x) for x in [*(cell[k] for k in ('fixture','controller_status','bank_plan','pilot_plan','analysis_intent','report','hardware')),raw]}
 manifest=tmp_path/'manifest.json';manifest.write_text(json.dumps(dict(plan_sha256=sha(plan),cells={'fit':hashes})))
 bindings=dict(hashes)
 for name in ('candidate_adapter','reference_adapter'):
  path=tmp_path/(name+'.py');path.write_text("def normalize(spec):\n return {'checked': bool(spec['artifact_hashes'])}\n");bindings[str(path)]=sha(path)
 seen=[]
 def normalize(spec):seen.append(spec);return {'checked':True}
 for name in ('candidate_adapter','reference_adapter'):monkeypatch.setitem(sys.modules,name,types.SimpleNamespace(normalize=normalize))
 pin=dict(plan=str(plan),artifact_manifest=str(manifest),adapter_paths={a:str(tmp_path/(n+'.py')) for a,n in [('public','candidate_adapter'),('reference','reference_adapter')]},study_directory=str(tmp_path),bindings=bindings)
 dispatch=verified_normalizer(pin);assert dispatch(cell)=={'checked':True}
 raw.write_text('{"changed":true}')
 with pytest.raises(ValueError):dispatch(cell)



def test_actual_separate_adapter_imports(tmp_path):
 import json
 from controller_transport import verified_normalizer
 from bank_transport import sha
 root=Path(__file__).resolve().parents[2]
 paths={'public':str(root/'target/posterior-bank-candidate-adapter/candidate_adapter.py'),'reference':str(root/'target/posterior-bank-candidate-controller/reference_adapter.py')}
 plan=tmp_path/'plan.json';plan.write_text('{}');manifest=tmp_path/'manifest.json';manifest.write_text(json.dumps(dict(plan_sha256=sha(plan),cells={})))
 pin=dict(plan=str(plan),artifact_manifest=str(manifest),adapter_paths=paths,study_directory=str(root/'STUDIES/options_flow_v1'),bindings={p:sha(p) for p in paths.values()})
 assert callable(verified_normalizer(pin))
