﻿"""External prospective candidate controller prototype. No default count or seeds."""
import argparse,copy,json,os,re,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
STUDY=HERE.parents[1]/'STUDIES/options_flow_v1'
ADAPTER=HERE.parent/'posterior-bank-candidate-adapter'
sys.path[:0]=[str(STUDY),str(ADAPTER)]
import candidate_adapter as adapter
from continuation_comparison import attested_dependencies
from mixed_flow_comparison import runtime
from asof_rolling_execute import validate_hardware

def save(p,v):
 p=Path(p)
 with p.open('x',encoding='utf8') as f:json.dump(v,f,indent=2,allow_nan=False)
def load(p):return adapter.load(p)
def sha(p):return adapter.sha(p)
def inventory():
 result={}
 for root in (STUDY,HERE,ADAPTER):
  for directory,subdirs,files in os.walk(root):
   subdirs[:]=[d for d in subdirs if d not in ('artifacts','__pycache__','.git','.venv')]
   for name in files:
    if name.endswith('.py'):
     p=Path(directory)/name;result[str(p.resolve())]=sha(p)
 return result
def command(p,c):
 if c.get('backend','public')=='reference':
  return [p['python'],str(STUDY/'hardware_control.py'),'--cpus','0','--record',c['hardware'],'--timeout',str(p['timeout_seconds']),'--',p['python'],str(STUDY/'mixed_flow_reference.py'),'--fixture',c['fixture'],'--out',c['worker_directory'],'--seed',str(c['sampler_seed']),'--warmup','1000','--chains','4','--tiers','1000','2000','4000','8000','--batch','1000','--target-accept','0.9','--implementation','associative']
 return [p['python'],str(STUDY/'hardware_control.py'),'--cpus','0','--record',c['hardware'],'--timeout',str(p['timeout_seconds']),'--',p['python'],str(STUDY/'pymc_flow_continuation_workflow.py'),'--fixture',c['fixture'],'--out',c['worker_directory'],'--seed',str(c['sampler_seed']),'--warmup','1000','--chains','4','--tiers','1000','2000','4000','8000','--model','flow','--block-size','32','--expected-cpus','0','--coordinates','mixed_slopes']
def validate_policy(policy):
 cells=policy['cells']
 if not cells or len({c['id'] for c in cells})!=len(cells) or any(not re.fullmatch(r'[A-Za-z0-9_-]+',c['id']) for c in cells):raise ValueError('Explicit nonempty unique safe intended IDs required')
 if any(c.get('backend','public') not in ('public','reference') for c in cells):raise ValueError('Unknown recipe')
 streams=[c[k] for c in cells for k in ('sampler_seed','initialization_seed','prediction_seed')]
 if any(type(x)is not int or not 0<=x<2**32 for x in streams) or any(c['prediction_seed']!=c['sampler_seed']+130000 for c in cells):raise ValueError('Valid uint32 streams and exact prediction rule required')
 if any('pair_id' in c for c in cells):
  pairs={}
  for c in cells:pairs.setdefault(c['pair_id'],[]).append(c)
  for rows in pairs.values():
   if len(rows)!=2 or {r.get('backend') for r in rows}!={'public','reference'} or rows[0]['initialization_seed']!=rows[1]['initialization_seed']:raise ValueError('Each pair requires both backends and shared initialization')
  unique=[rows[0]['initialization_seed'] for rows in pairs.values()]+[c[k] for c in cells for k in ('sampler_seed','prediction_seed')]
  if len(set(unique))!=len(unique):raise ValueError('Cross-pair or cross-role stream collision')
 else:
  if len(set(streams))!=len(streams):raise ValueError('Distinct uint32 streams required')
 for k in ('timeout_seconds','total_seconds'):
  if not adapter.finite(policy[k]) or policy[k]<=15:raise ValueError('Explicit finite budgets >15 seconds required')
 return streams

def verify_seed_evidence(path,seeds):
 audit=load(path)
 if audit.get('status')!='passed' or audit.get('hits')!=[] or set(audit.get('seeds',[]))!=set(seeds):raise ValueError('Exact seed evidence differs')
 evidence=audit.get('supplemental_evidence');bindings={str(Path(path).resolve()):sha(path)}
 if evidence:
  if sha(evidence['path'])!=evidence['sha256']:raise ValueError('Seed supplement drift')
  broad=load(evidence['path']);bindings[str(Path(evidence['path']).resolve())]=evidence['sha256']
  if broad.get('status')!='passed' or broad.get('hits')!=[] or not set(seeds)<=set(broad.get('seeds',[])):raise ValueError('Seed supplement does not cover streams')
 else:broad=audit
 if broad.get('prior_reserved'):
  reserved=broad['prior_reserved']
  if sha(reserved['path'])!=reserved['sha256']:raise ValueError('Reserved historical inventory changed')
  if set(seeds)&set(load(reserved['path'])['reserved_seeds']):raise ValueError('Historically reserved stream collision')
  bindings[str(Path(reserved['path']).resolve())]=reserved['sha256']
 if not broad.get('inventory_files'):raise ValueError('Missing searched inventory')
 for file,h in broad['inventory_files'].items():
  if sha(file)!=h:raise ValueError('Seed inventory changed; refresh primary evidence: '+file)
 return bindings

def decision_bindings(intent_path,cells,target):
 intent=load(intent_path)
 if intent.get('schema')!='paired_decision_intent_v1' or intent.get('pair_count')!=36 or intent.get('intended_fits')!=72 or intent.get('outer_replicates')!=40000 or intent.get('target_sha256')!=target:raise ValueError('Decision intent target/counts differ')
 if len(cells)!=72:raise ValueError('Exact72 intended fits required')
 bound={str(Path(intent_path).resolve()):sha(intent_path)}
 for key in ('sources','bindings'):
  if not intent.get(key):raise ValueError('Decision sources/bindings missing')
  for path,h in intent[key].items():
   if sha(path)!=h:raise ValueError('Decision input/source drift')
   bound[str(Path(path).resolve())]=h
 for key in ('pair_map','counts','bank_indices','bank_pin','seed_audit'):
  if str(Path(intent[key]).resolve()) not in bound:raise ValueError('Unbound decision component')
 pairs=load(intent['pair_map'])
 if isinstance(pairs,dict):pairs=pairs.get('pairs')
 if not isinstance(pairs,list) or len(pairs)!=36:raise ValueError('Decision pair map malformed')
 for i,pair in enumerate(pairs):
  rows=cells[2*i:2*i+2];order=['public','reference'] if i%2==0 else ['reference','public']
  if pair['id']!=f'pair{i:02d}' or [r.get('backend') for r in rows]!=order or any(r.get('pair_id')!=pair['id'] or r['id']!=pair[r['backend']] for r in rows):raise ValueError('Decision pair mapping/order differs')
  if rows[0]['initialization_seed']!=rows[1]['initialization_seed']:raise ValueError('Matched physical starts require shared init')
 import numpy as np
 counts=np.load(intent['counts'],mmap_mode='r',allow_pickle=False);indices=np.load(intent['bank_indices'],mmap_mode='r',allow_pickle=False)
 if counts.shape!=(40000,36) or counts.dtype!=np.dtype('int32') or (counts<0).any() or not (counts.sum(axis=1)==36).all() or indices.shape!=(40000,) or indices.dtype!=np.dtype('int32') or (indices<0).any() or (indices>=30000).any():raise ValueError('Decision resampling arrays malformed')
 return bound

def prepare(out,policy,fixture,python,package,attestation,bank_plan,pilot_plan,analysis_intent,seed_audit,decision_intent):
 streams=validate_policy(policy);out=Path(out).resolve()
 if out.exists():raise FileExistsError(out)
 excluded={c[k] for path in (bank_plan,pilot_plan) for c in load(path)['cells'] for k in ('seed','init_seed','predictive_seed')};excluded.add(load(analysis_intent)['analysis_policy']['bootstrap_seed'])
 if excluded.intersection(streams):raise ValueError('Bank/pilot/bootstrap streams excluded')
 audit=load(seed_audit)
 if audit.get('status')!='passed' or sorted(audit.get('seeds',[]))!=sorted(set(streams)) or audit.get('hits')!=[] or not audit.get('scope'):raise ValueError('Exact historical seed audit required')
 seed_bindings=verify_seed_evidence(seed_audit,set(streams))
 original=load(fixture)
 from posterior_resource.controller import posterior
 from masked_market_comparison_plan import dispersed_starts
 if len(original['data']['y'])!=1000 or any(len(r)!=4 for r in original['data']['y']):raise ValueError('Exact fixed T1000/G4 target required')
 python=str(Path(python).resolve());package=str(Path(package).resolve())
 p=dict(schema='fresh_mixed_candidate_controller_v1',qualified=False,cells=[],python=python,pythonpath=package,timeout_seconds=policy['timeout_seconds'],total_seconds=policy['total_seconds'],cleanup_reserve_seconds=15,bank_posterior_sha256=posterior(original),predictive_contract=policy['predictive_contract'],runtime=runtime(python),sources=inventory(),bindings=attested_dependencies(attestation,python,package))
 for path in (fixture,python,attestation,bank_plan,pilot_plan,analysis_intent,seed_audit,Path(package)/'owalnuts/__init__.py',Path(package)/'owalnuts/_owalnuts.pyd'):p['bindings'][str(Path(path).resolve())]=sha(path)
 p['decision_intent']=str(Path(decision_intent).resolve());p['bindings'].update(decision_bindings(decision_intent,policy['cells'],p['bank_posterior_sha256']))
 p['bindings'].update(seed_bindings)
 out.mkdir(parents=True)
 for entry in policy['cells']:
  c=copy.deepcopy(entry);prefix=out/c['id'];f=copy.deepcopy(original);f['data']['initial_positions']=dispersed_starts(1000,4,f['data']['rho'],c['initialization_seed']);fp=out/(c['id']+'-fixture.json');save(fp,f)
  c.update(controller_id=c['id'],fixture=str(fp),fixture_sha256=sha(fp),worker_directory=str(prefix),report=str(prefix/'python-pymc-flow-report.json'),controller_status=str(out/(c['id']+'-status.json')),hardware=str(out/(c['id']+'-hardware.json')),started=str(out/(c['id']+'-started.json')),exit=str(out/(c['id']+'-exit.json')),log=str(out/(c['id']+'-log.txt')),bank_plan=str(Path(bank_plan).resolve()),pilot_plan=str(Path(pilot_plan).resolve()),analysis_intent=str(Path(analysis_intent).resolve()),bank_posterior_sha256=p['bank_posterior_sha256'],predictive_contract=p['predictive_contract'],timeout_seconds=p['timeout_seconds'])
  # Exactly the paths emitted by the existing public worker, not controller-only files.
  repo=STUDY.parents[1];worker_paths=[fp,Path(python),Path(package)/'owalnuts/__init__.py',Path(package)/'owalnuts/_owalnuts.pyd',repo/'Cargo.toml',repo/'Cargo.lock',*repo.joinpath('src').rglob('*.rs'),repo/'integrations/python/Cargo.toml',repo/'integrations/python/Cargo.lock',*repo.joinpath('integrations/python/src').rglob('*.rs'),*STUDY.glob('*.py')]
  if c.get('backend','public')=='reference':
   c['report']=str(prefix/'report.json');worker_paths=[fp,Path(python),*STUDY.glob('*.py')]
  c['worker_bindings']={str(x.resolve()):sha(x) for x in worker_paths};c['command']=command(p,c);p['cells'].append(c);p['bindings'][str(fp)]=sha(fp)
 p['seed_audit']=str(Path(seed_audit).resolve());save(out/'plan-draft.json',p);return p

def verify(path,p,digest):
 if sha(path)!=digest or Path(path).with_suffix('.sha256').read_text().strip()!=digest:raise ValueError('Frozen plan drift')
 if inventory()!=p['sources'] or any(sha(k)!=v for k,v in p['bindings'].items()) or runtime(p['python'])!=p['runtime']:raise ValueError('Source/input/runtime drift')
 for c in p['cells']:
  if c['command']!=command(p,c):raise ValueError('Worker command differs')
def freeze(draft):
 draft=Path(draft);p=load(draft);streams=validate_policy(p)
 if 'seed_audit' in p:verify_seed_evidence(p['seed_audit'],set(streams))
 for c in p['cells']:
  if any(Path(c[k]).exists() for k in ('worker_directory','controller_status','hardware','started','exit','log')):raise ValueError('Prior cell activity')
 if inventory()!=p['sources'] or any(sha(k)!=v for k,v in p['bindings'].items()):raise ValueError('Draft drift')
 if (draft.parent/'plan.json').exists() or (draft.parent/'plan.sha256').exists():raise FileExistsError('Frozen plan or sidecar exists')
 if 'decision_intent' not in p:raise ValueError('Prefitting decision intent required')
 decision_bindings(p['decision_intent'],p['cells'],p['bank_posterior_sha256'])
 path=draft.parent/'plan.json'
 if path.exists() or path.with_suffix('.sha256').exists():raise FileExistsError('Frozen plan or sidecar exists')
 save(path,p);
 with path.with_suffix('.sha256').open('x',encoding='utf8') as f:f.write(sha(path))
 return path

def execute(path):
 path=Path(path).resolve();p=load(path);digest=sha(path);tick=time.perf_counter();outcomes=[]
 if any((path.parent/name).exists() for name in ('execution-started.json','terminal.json','terminal-cost.json')):raise FileExistsError('No retry of started campaign')
 for c in p['cells']:
  if any(Path(c[k]).exists() for k in ('worker_directory','controller_status','hardware','started','exit','log')):raise FileExistsError('No retry of started cell')
 save(path.parent/'execution-started.json',dict(plan_sha256=digest))
 aborted=False
 for c in p['cells']:
  start=time.perf_counter();r=dict(id=c['id'],status='unattempted',success=False,returncode=None,elapsed_seconds=0)
  try:
   if aborted:raise ValueError('Campaign aborted after provenance failure')
   try:verify(path,p,digest)
   except Exception:
    aborted=True;raise
   if p['total_seconds']-(time.perf_counter()-tick)<p['timeout_seconds']+15:raise RuntimeError('Insufficient remaining full cell budget')
   save(c['started'],dict(id=c['id'],plan_sha256=digest,command=c['command']))
   env=dict(os.environ,PYTHONPATH=p['pythonpath'])
   with Path(c['log']).open('x') as log:rc=subprocess.run(c['command'],env=env,stdout=log,stderr=subprocess.STDOUT).returncode
   r['returncode']=rc;save(c['exit'],dict(returncode=rc));h=load(c['hardware']);validate_hardware(h,c['command'],rc,p['timeout_seconds'])
   try:verify(path,p,digest)
   except Exception:
    aborted=True;raise
   r.update(status='completed' if rc==0 and h['status']=='completed' else 'worker_failed',success=rc==0 and h['status']=='completed')
  except Exception as exc:r.update(status='failed' if Path(c['started']).exists() else 'unattempted',error=f'{type(exc).__name__}: {exc}')
  r['elapsed_seconds']=time.perf_counter()-start
  try:save(c['controller_status'],r)
  except Exception as exc:r.update(success=False,status='failed',status_write_error=f'{type(exc).__name__}: {exc}')
  normalized=dict(outcome='invalid_or_missing',endpoints={},error='Normalization not completed')
  try:
   spec=dict(c);spec['artifact_hashes']={str(Path(x).resolve()):sha(x) for x in [c['fixture'],c['controller_status'],c['bank_plan'],c['pilot_plan'],c['analysis_intent'],c['report'],c['hardware'],*Path(c['worker_directory']).glob('draws-*/*.json'),*Path(c['worker_directory']).glob('draws-*.json')] if Path(x).is_file()}
   if c.get('backend','public')=='reference':
    from reference_adapter import normalize
   else:normalize=adapter.normalize
   normalized=normalize(spec)
   try:verify(path,p,digest)
   except Exception:
    aborted=True;raise
  except Exception as exc:
   normalized.update(outcome='invalid_or_missing',endpoints={},error=f'{type(exc).__name__}: {exc}')
  full=time.perf_counter()-start
  outcomes.append(dict(controller=r,normalized=normalized,worker_wrapper_and_preflight_seconds=r['elapsed_seconds'],postprocessing_seconds=max(0,full-r['elapsed_seconds']),full_cell_seconds=full))
 result=dict(expected=len(p['cells']),outcomes=outcomes,elapsed_seconds=time.perf_counter()-tick,qualified=False,plan_sha256=digest)
 result['budget_status']='within_admission_budget' if result['elapsed_seconds']<=p['total_seconds'] else 'total_budget_unresolved'
 result['cost_policy']='full_cell_seconds includes wrapper/preflight plus postprocessing; do not add these components again. Terminal elapsed includes inter-cell overhead through terminal record preparation; terminal file serialization is separately reported.'
 save(path.parent/'terminal.json',result)
 save(path.parent/'terminal-cost.json',dict(total_seconds_including_terminal_serialization=time.perf_counter()-tick,total_budget_unresolved=time.perf_counter()-tick>p['total_seconds']))
 return result

def main():
 parser=argparse.ArgumentParser();parser.add_argument('operation',choices=['freeze','run']);parser.add_argument('plan',type=Path);a=parser.parse_args()
 if a.operation=='freeze':freeze(a.plan)
 else:execute(a.plan)
if __name__=='__main__':main()
