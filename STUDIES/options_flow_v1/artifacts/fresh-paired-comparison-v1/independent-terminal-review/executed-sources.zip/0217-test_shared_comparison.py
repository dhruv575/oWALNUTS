import sys
sys.path.insert(0,'C:/dev/owalnuts/STUDIES/options_flow_v1')
import pytest
from shared_comparison import compare
N=[f'e{i}' for i in range(12)]
def v(x):return {k:float(x) for k in N}
def run(ids,candidates,banks,counts,indices,eps=0.):return compare(ids,candidates,N,banks,counts,indices,v(eps))

def test_constant_candidates_do_not_shrink_shared_reference():
    banks=[v(-2),v(0),v(2)]
    one=run(['a'],[dict(id='a',usable=True,endpoints=v(0))],banks,[{'a':1}]*3,[0,1,2])
    ids=[str(i) for i in range(50)];many=run(ids,[dict(id=k,usable=True,endpoints=v(0)) for k in ids],banks,[dict.fromkeys(ids,1)]*3,[0,1,2])
    for a,b in zip(one['replicates'],many['replicates']):
        for k in N:
            assert a['statistics'][k]['signed_mean_error']==b['statistics'][k]['signed_mean_error']
            assert a['statistics'][k]['rms_error']==pytest.approx(b['statistics'][k]['rms_error'],abs=1e-14)

def test_correlated_endpoint_vector_and_lipschitz_bounds():
    bank={k:float(i-5) for i,k in enumerate(N)}
    r=run(['a'],[dict(id='a',usable=True,endpoints=v(0))],[bank],[{'a':1}],[0],.25)['replicates'][0]['statistics']
    for k in N:
        assert r[k]['signed_mean_error']==-bank[k]
        assert r[k]['rms_estimated_numerical_envelope']==[max(0,abs(bank[k])-.25),abs(bank[k])+.25]
        assert r[k]['numerical_bound_certified'] is False

def test_variable_weights_missing_and_failed_denominator():
    out=run(['a','b','bad','missing'],[dict(id='a',usable=True,endpoints=v(1)),dict(id='b',usable=True,endpoints=v(3)),dict(id='bad',usable=False,status='failed')],[v(0)],[{'a':1,'b':3,'bad':2,'missing':1},{'bad':1}],[0,0])
    assert out['expected_candidates']==4 and out['usable_candidates']==2
    assert out['replicates'][0]['statistics']['e0']['signed_mean_error']==2.5
    assert out['replicates'][0]['excluded_unusable_weight']==3
    assert out['replicates'][1]['statistics'] is None

def test_independent_reference_negative_control():
    result=run(['a','b'],[dict(id=k,usable=True,endpoints=v(0)) for k in ['a','b']],[v(-1),v(1)],[{'a':1,'b':1}]*2,[0,1])
    shared=[r['statistics']['e0']['signed_mean_error'] for r in result['replicates']]
    independent_wrong=[(-(-1)-1)/2]*2
    assert shared==[1.,-1.] and independent_wrong==[0.,0.]

@pytest.mark.parametrize('counts,index',[({'a':True},0),({'a':-1},0),({'a':0},0),({'extra':1},0),({'a':1},True),({'a':1},2)])
def test_invalid_inputs(counts,index):
    with pytest.raises(ValueError):run(['a'],[dict(id='a',usable=True,endpoints=v(0))],[v(0)],[counts],[index])

def test_duplicate_or_nonfinite_candidate_rejected():
    c=dict(id='a',usable=True,endpoints=v(0))
    with pytest.raises(ValueError):run(['a'],[c,c],[v(0)],[{'a':1}],[0])
    with pytest.raises(ValueError):run(['a'],[dict(c,endpoints=v(float('nan')))],[v(0)],[{'a':1}],[0])


def test_nonuniform_rms_and_shared_shift_envelopes():
 candidates=[dict(id='a',usable=True,endpoints=v(-2)),dict(id='b',usable=True,endpoints=v(4))]
 result=run(['a','b'],candidates,[v(1)],[{'a':3,'b':1}],[0],.3)['replicates'][0]['statistics']['e0']
 assert result['signed_mean_error']==-1.5
 assert result['rms_error']==pytest.approx(3.)
 for shift in [-.3,.1,.3]:
  actual=((3*(-3-shift)**2+(3-shift)**2)/4)**.5
  lo,hi=result['rms_estimated_numerical_envelope'];assert lo<=actual<=hi


def test_empty_endpoint_name_rejected():
 names=N[:-1]+['']
 with pytest.raises(ValueError):compare(['a'],[],names,[dict.fromkeys(names,0.)],[{'a':1}],[0],dict.fromkeys(names,0.))
