"""Associative reference schema adapter; shares gates, no invented callback telemetry."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'posterior-bank-candidate-adapter'))
from candidate_adapter import *

def validate_current_report(spec,report,fixture):
 from continuation_comparison import norm
 if report.get('arm')!='numpyro-mixed-slopes-continuation' or report.get('model')!='flow' or report.get('coordinates')!='mixed_slopes' or report.get('implementation')!='associative':raise ValueError('Wrong reference recipe')
 if report['settings']!=dict(implementation='associative',warmup=1000,chains=4,tiers=list(TIERS),batch=1000,target_accept=.9):raise ValueError('Reference settings differ')
 if norm(report['bindings'])!=norm(spec['worker_bindings']):raise ValueError('Reference bindings differ')
 if report['seed']!=spec['sampler_seed'] or report['predictive_seed']!=spec['prediction_seed'] or spec['prediction_seed']!=spec['sampler_seed']+130000:raise ValueError('Reference streams differ')
 if report['initial_positions']!=fixture['data']['initial_positions']:raise ValueError('Reference starts differ')
 if report['precision_plan']!=dict(names=list(FUNCTIONALS),forecast_rows=4,threshold=.02,tiers=list(TIERS)):raise ValueError('Reference precision family differs')
 if report['parity'].get('passed') is not True or report['hardware_control']['realized_cpus']!=[0]:raise ValueError('Reference parity/affinity failed')
 cross=target_crosswalk(fixture,spec['predictive_contract'])
 if cross['bank_posterior_sha256']!=spec['bank_posterior_sha256']:raise ValueError('Reference posterior differs')
 return cross

def validate_retention(spec,report,fixture):
 from asof_rolling_execute import validate_checkpoint_continuity
 from continuation_comparison import validate_raw_starts
 from masked_market_comparison_execute import tail_field
 from flow_mixed_coordinates import to_mixed
 import numpy as np
 attempts=report['attempts'];tiers=[a['draws'] for a in attempts]
 if not tiers or tiers!=list(TIERS[:len(tiers)]):raise ValueError('Reference tier sequence differs')
 previous=[];checks=[]
 for i,attempt in enumerate(attempts):
  tier=attempt['draws'];folder=Path(spec['worker_directory']);fp=folder/f'draws-{tier}-report.json';raw=folder/f'draws-{tier}-raw.json'
  if any(str(p.resolve()) not in spec['artifact_hashes'] for p in (fp,raw)):raise ValueError('Unbound reference retained artifact')
  fit=load(fp);passed=gate(fit);checkpoints=fit['checkpoints'];validate_checkpoint_continuity(checkpoints)
  if len(checkpoints)!=tier//1000 or checkpoints[:len(previous)]!=previous:raise ValueError('Reference checkpoint prefix differs')
  previous=checkpoints
  if fit['draws']!=tier or passed!=attempt['screen']['pass'] or passed and i!=len(attempts)-1:raise ValueError('Reference firstpass differs')
  validate_raw_starts(raw,fixture['data']['initial_positions'])
  np.testing.assert_array_equal(np.asarray(tail_field(raw,'sampling_initial_positions')),to_mixed(np.asarray(fixture['data']['initial_positions']),fixture['data']))
  checks.append(dict(draws=tier,pass_gate=passed))
 for key in ('evaluation','retained_divergences','checkpoints'):
  if report[key]!=fit[key]:raise ValueError('Reference final selected output differs')
 final=gate(report)
 if report['draws']!=tiers[-1] or final!=report['precision_pass'] or not final and tiers[-1]!=8000:raise ValueError('Reference terminal differs')
 if not finite(report['adapt_seconds']) or report['adapt_seconds']<0:raise ValueError('Reference adaptation cost missing')
 expected=report['adapt_seconds']+sum(a['sampling_seconds'] for a in attempts)
 if not math.isclose(report['total_sampling_seconds'],expected,rel_tol=1e-12,abs_tol=1e-9):raise ValueError('Reference sampling accounting differs')
 return dict(selected_tier=tiers[-1],attempt_checks=checks,healthy=report['healthy'],precision_pass=final,outcome='usable' if final else 'precision_or_health_failed',endpoints=selected_endpoints(report),adapt_seconds=report['adapt_seconds'],checkpoint_count=len(previous))

def normalize(spec):
 """One declared fresh repetition; failures retain identity and separate cost scopes."""
 output=dict(schema='current_mixed_workflow_candidate_v1',id=spec['id'],qualified=False,outcome='invalid_or_missing',endpoints={},policy='first-passing-1000-2000-4000-8000',costs=dict(wrapper_seconds=None,worker_seconds=None,scope='Separate measurements; never sum worker time into wrapper total'))
 try:
  status=load(spec['controller_status']);output['original_controller_status']=status;output['terminal_outcome']=status.get('status')
  outer=status.get('elapsed_seconds')
  if finite(outer) and outer>=0:output['costs']['wrapper_seconds']=outer
  if status.get('id')!=spec['controller_id']:raise ValueError('Controller identity differs')
  required=[spec[k] for k in ['report','fixture','controller_status','hardware','bank_plan','pilot_plan','analysis_intent']]
  if any(str(Path(p).resolve()) not in spec['artifact_hashes'] for p in required):raise ValueError('Missing required frozen provenance artifact')
  for path,h in spec['artifact_hashes'].items():
   if sha(path)!=h:raise ValueError('Frozen candidate artifact changed')
  report=load(spec['report']);seconds=report.get('end_to_end_seconds')
  if finite(seconds) and seconds>=0:output['costs']['worker_seconds']=seconds
  fixture=load(spec['fixture'])
  if sha(spec['fixture'])!=spec['fixture_sha256']:raise ValueError('Fixture hash differs')
  output['target_crosswalk']=validate_current_report(spec,report,fixture)
  streams=[spec[k] for k in ['sampler_seed','initialization_seed','prediction_seed']]
  excluded={c[k] for path in [spec['bank_plan'],spec['pilot_plan']] for c in load(path)['cells'] for k in ['seed','init_seed','predictive_seed']}
  excluded.add(load(spec['analysis_intent'])['analysis_policy']['bootstrap_seed'])
  if any(type(s)is not int or not 0<=s<2**32 for s in streams) or len(set(streams))!=3 or set(streams)&excluded:raise ValueError('Fresh candidate streams collide')
  from masked_market_comparison_plan import dispersed_starts
  if fixture['data']['initial_positions']!=dispersed_starts(1000,4,fixture['data']['rho'],spec['initialization_seed']):raise ValueError('Fresh initialization stream does not reproduce starts')
  output['streams']=dict(sampler_seed=spec['sampler_seed'],initialization_seed=spec['initialization_seed'],prediction_seed=spec['prediction_seed'])
  from asof_rolling_execute import validate_hardware
  h=load(spec['hardware']);validate_hardware(h,spec['command'],status['returncode'],spec['timeout_seconds'])
  if report.get('status')!='completed':output['outcome']='worker_failed';return output
  output.update(validate_retention(spec,report,fixture))
  final=output['precision_pass']
  if final:validate_success_terminal(status,h)
 except Exception as exc:output.update(outcome='invalid_or_missing',error=f'{type(exc).__name__}: {exc}',endpoints={})
 return output


