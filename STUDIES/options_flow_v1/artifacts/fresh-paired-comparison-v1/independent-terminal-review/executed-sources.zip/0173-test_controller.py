﻿import copy,json,subprocess,sys
from pathlib import Path
import pytest
import controller as c

def policy():return dict(cells=[dict(id='a',sampler_seed=1,initialization_seed=2,prediction_seed=130001)],timeout_seconds=20,total_seconds=60)
def fixture(tmp_path):
 p=policy();p.update(python=sys.executable,pythonpath=str(tmp_path));cell=p['cells'][0]
 for key,suffix in [('fixture','fixture.json'),('controller_status','status.json'),('hardware','hardware.json'),('started','started.json'),('exit','exit.json'),('log','log.txt'),('report','worker/report.json'),('worker_directory','worker'),('bank_plan','bank.json'),('pilot_plan','pilot.json'),('analysis_intent','intent.json')]:cell[key]=str(tmp_path/suffix)
 cell['command']=c.command(p,cell);path=tmp_path/'plan.json';c.save(path,p);return path,p

@pytest.mark.parametrize('change',['repeat','bool','prediction','id','budget'])
def test_policy_rejects(change):
 p=policy()
 if change=='repeat':p['cells'].append(dict(p['cells'][0],id='b'))
 elif change=='bool':p['cells'][0]['initialization_seed']=True
 elif change=='prediction':p['cells'][0]['prediction_seed']=5
 elif change=='id':p['cells'][0]['id']='../escape'
 else:p['total_seconds']=float('nan')
 with pytest.raises(ValueError):c.validate_policy(p)

@pytest.mark.parametrize('mode',['completed','failed','missing','drift'])
def test_lifecycle_stub_worker(tmp_path,monkeypatch,mode):
 path,p=fixture(tmp_path);seen=[]
 def verify(*args):
  seen.append(1)
  if mode=='drift' and len(seen)>1:raise ValueError('drift')
 monkeypatch.setattr(c,'verify',verify)
 def worker(args,**kw):
  cell=p['cells'][0]
  if mode!='missing':c.save(cell['hardware'],dict(status='completed' if mode!='failed' else 'worker-failed'))
  return type('R',(),dict(returncode=1 if mode=='failed' else 0))()
 monkeypatch.setattr(c.subprocess,'run',worker);monkeypatch.setattr(c,'validate_hardware',lambda *a:None)
 monkeypatch.setattr(c.adapter,'normalize',lambda spec:dict(outcome='stub-schema-only',costs={'wrapper_seconds':c.load(spec['controller_status'])['elapsed_seconds']}))
 r=c.execute(path);assert r['expected']==1 and len(r['outcomes'])==1 and r['elapsed_seconds']>=0
 row=r['outcomes'][0]['controller'];assert row['success']==(mode=='completed')
 assert Path(p['cells'][0]['exit']).exists()
 with pytest.raises(FileExistsError):c.execute(path)

def test_admission_failure_preserves_all_unstarted(tmp_path,monkeypatch):
 path,p=fixture(tmp_path)
 monkeypatch.setattr(c,'verify',lambda *a:(_ for _ in ()).throw(ValueError('stale source')))
 monkeypatch.setattr(c.subprocess,'run',lambda *a,**k:pytest.fail('Must not launch'))
 monkeypatch.setattr(c.adapter,'normalize',lambda s:dict(outcome='invalid_or_missing'))
 r=c.execute(path);assert r['expected']==1 and r['outcomes'][0]['controller']['status']=='unattempted'
 assert not Path(p['cells'][0]['started']).exists()

def test_actual_worker_cli_schema_without_sampling():
 result=subprocess.run([sys.executable,str(c.STUDY/'pymc_flow_continuation_workflow.py'),'--help'],capture_output=True,text=True)
 assert result.returncode==0
 for flag in ['--fixture','--out','--seed','--warmup','--chains','--tiers','--model','--block-size','--coordinates','--expected-cpus']:assert flag in result.stdout
 assert 'mixed_slopes' in result.stdout

def test_controller_actual_cli():
 result=subprocess.run([sys.executable,str(Path(c.__file__)),'--help'],capture_output=True,text=True)
 assert result.returncode==0 and 'freeze' in result.stdout and 'run' in result.stdout

def test_actual_reference_saved_schema_and_retention():
 import reference_adapter as r
 root=c.STUDY/'artifacts/optimized-mixed-comparison-v1/pair0-numpyro_mixed'
 report=c.load(root/'report.json');fixture_path=c.STUDY/'artifacts/python-flow-long-v1/fixture.json';f=c.load(fixture_path)
 from posterior_resource.controller import posterior
 spec=dict(fixture=str(fixture_path),sampler_seed=report['seed'],prediction_seed=report['predictive_seed'],worker_bindings=report['bindings'],bank_posterior_sha256=posterior(f),predictive_contract='one-step observed StudentT; actual supplied future flow',worker_directory=str(root),artifact_hashes={str(p.resolve()):c.sha(p) for p in root.glob('draws-*.json')})
 r.validate_current_report(spec,report,f);result=r.validate_retention(spec,report,f)
 assert result['outcome']=='usable' and len(result['endpoints'])==12
 bad=copy.deepcopy(report);bad['total_sampling_seconds']+=1
 with pytest.raises(ValueError,match='accounting'):r.validate_retention(spec,bad,f)
 bad=copy.deepcopy(report);bad['evaluation']['functionals']['tau']['interval_90'][0]+=.0001
 with pytest.raises(ValueError,match='final selected'):r.validate_retention(spec,bad,f)

def test_actual_reference_cli_schema_without_sampling():
 result=subprocess.run([sys.executable,str(c.STUDY/'mixed_flow_reference.py'),'--help'],capture_output=True,text=True)
 assert result.returncode==0 and '--implementation' in result.stdout and 'associative' in result.stdout

def test_normalizer_exception_retains_later_ids(tmp_path,monkeypatch):
 path,p=fixture(tmp_path);second=copy.deepcopy(p['cells'][0]);second['id']='b'
 for k in ('fixture','controller_status','hardware','started','exit','log','report','worker_directory','bank_plan','pilot_plan','analysis_intent'):second[k]=second[k].replace(str(tmp_path),str(tmp_path/'b'))
 (tmp_path/'b').mkdir();p['cells'].append(second);path.write_text(json.dumps(p))
 monkeypatch.setattr(c,'verify',lambda *a:(_ for _ in ()).throw(ValueError('admission')))
 monkeypatch.setattr(c.adapter,'normalize',lambda *a:(_ for _ in ()).throw(OSError('read failed')))
 r=c.execute(path)
 assert [v['controller']['id'] for v in r['outcomes']]==['a','b']
 assert all(v['normalized']['outcome']=='invalid_or_missing' and v['full_cell_seconds']>=v['controller']['elapsed_seconds'] for v in r['outcomes'])
 assert (tmp_path/'terminal-cost.json').exists()

def test_freeze_existing_sidecar_is_not_overwritten(tmp_path,monkeypatch):
 p=policy();p.update(sources={},bindings={});p['cells']=[]
 # Admission mocked solely to reach exclusive sidecar boundary.
 monkeypatch.setattr(c,'validate_policy',lambda p:None);monkeypatch.setattr(c,'inventory',lambda:{})
 draft=tmp_path/'plan-draft.json';c.save(draft,p);side=tmp_path/'plan.sha256';side.write_text('original')
 with pytest.raises(FileExistsError):c.freeze(draft)
 assert side.read_text()=='original' and not (tmp_path/'plan.json').exists()

def test_postprocessing_overrun_explicitly_unresolved(tmp_path,monkeypatch):
 path,p=fixture(tmp_path);p['total_seconds']=1;path.write_text(json.dumps(p));clock=[0]
 monkeypatch.setattr(c.time,'perf_counter',lambda:clock[0]);monkeypatch.setattr(c,'verify',lambda *a:None)
 def normalize(spec):clock[0]=5;return dict(outcome='invalid_or_missing')
 monkeypatch.setattr(c.adapter,'normalize',normalize)
 r=c.execute(path)
 assert r['budget_status']=='total_budget_unresolved' and r['outcomes'][0]['postprocessing_seconds']==5
 assert c.load(tmp_path/'terminal-cost.json')['total_budget_unresolved'] is True

def test_inventory_recursively_binds_study_packages(tmp_path,monkeypatch):
 study=tmp_path/'study';package=study/'posterior_resource';package.mkdir(parents=True);nested=package/'new.py';nested.write_text('x=1')
 archive=study/'artifacts';archive.mkdir();(archive/'historical.py').write_text('old')
 monkeypatch.setattr(c,'STUDY',study);before=c.inventory();assert str(nested.resolve()) in before and str((archive/'historical.py').resolve()) not in before
 nested.write_text('x=2');assert c.inventory()!=before
 (package/'added.py').write_text('y=1');assert str((package/'added.py').resolve()) in c.inventory()

def test_pair_shared_init_only():
 p=policy();p['cells']=[dict(p['cells'][0],pair_id='pair00',backend='public'),dict(id='b',pair_id='pair00',backend='reference',sampler_seed=3,initialization_seed=2,prediction_seed=130003)]
 c.validate_policy(p)
 p['cells'][1]['initialization_seed']=4
 with pytest.raises(ValueError,match='shared initialization'):c.validate_policy(p)

def test_seed_inventory_rehashed(tmp_path):
 source=tmp_path/'old.json';source.write_text('{}');audit=tmp_path/'audit.json'
 c.save(audit,dict(status='passed',hits=[],seeds=[1],inventory_files={str(source):c.sha(source)}))
 c.verify_seed_evidence(audit,[1]);source.write_text('changed')
 with pytest.raises(ValueError,match='inventory changed'):c.verify_seed_evidence(audit,[1])

def test_decision_intent_mapping_arrays_and_source_bound(tmp_path):
 import numpy as np
 cells=[];pairs=[]
 for i in range(36):
  pair=f'pair{i:02d}';pairs.append(dict(id=pair,public=pair+'-public',reference=pair+'-reference'))
  for backend in (['public','reference'] if i%2==0 else ['reference','public']):cells.append(dict(id=pair+'-'+backend,pair_id=pair,backend=backend,initialization_seed=i))
 pp=tmp_path/'pairs.json';c.save(pp,pairs);cp=tmp_path/'counts.npy';bp=tmp_path/'indices.npy';np.save(cp,np.ones((40000,36),dtype=np.int32));np.save(bp,np.zeros(40000,dtype=np.int32))
 pin=tmp_path/'bank.json';audit=tmp_path/'audit.json';c.save(pin,{});c.save(audit,{})
 source=tmp_path/'decision.py';source.write_text('# pinned')
 intent=dict(schema='paired_decision_intent_v1',pair_count=36,intended_fits=72,outer_replicates=40000,target_sha256='target',pair_map=str(pp),counts=str(cp),bank_indices=str(bp),bank_pin=str(pin),seed_audit=str(audit),sources={str(source):c.sha(source)},bindings={str(p):c.sha(p) for p in (pp,cp,bp,pin,audit)})
 ip=tmp_path/'intent.json';c.save(ip,intent);assert str(ip) in c.decision_bindings(ip,cells,'target')
 bad=copy.deepcopy(cells);bad[0]['id']='other'
 with pytest.raises(ValueError,match='mapping'):c.decision_bindings(ip,bad,'target')
 source.write_text('# drift')
 with pytest.raises(ValueError,match='drift'):c.decision_bindings(ip,cells,'target')
