"""Current mixed-continuation normalization prototype; no fitting or inferred legacy fields.
Static draft: helpers are imported only when explicitly called after timing hold.
"""
import hashlib,json,math
from pathlib import Path
TIERS=(1000,2000,4000,8000)
PARAMETERS=('beta_bar','tau','mu_h','sigma_h','h_terminal')
FUNCTIONALS=PARAMETERS+('h_mean',)+tuple(p+str(g) for g in range(4) for p in ('alpha_','beta_'))
ARM='python-pymc-flow-mixed_slopes-continuation'


def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()

def load(path):return json.loads(Path(path).read_text())
def finite(value):return type(value) in (int,float) and math.isfinite(value)
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def target_crosswalk(fixture,predictive_contract):
 from posterior_resource.controller import posterior
 from endpoint_replicates import predictive_inputs
 data={k:v for k,v in fixture['data'].items() if k!='initial_positions'}
 if len(data['y'])!=1000 or any(len(row)!=4 for row in data['y']) or len(fixture['holdout']['x'])!=1 or len(fixture['holdout']['x'][0])!=4:raise ValueError('Exact T1000G4one-step target required')
 return dict(bank_posterior_sha256=posterior(fixture),replicate_target_sha256=digest(dict(data=data,predictive_contract=predictive_contract,predictive_inputs=predictive_inputs(fixture))),predictive_contract=predictive_contract,predictive_inputs=predictive_inputs(fixture),note='Both hashes recomputed from same data and actual forecast inputs; truth, starts and held-out outcomes do not define either target')


def gate(fit):
 from precision_tiers import precision_screen
 ev=fit['evaluation'];functions=ev['functionals'];coordinates=ev['canonical_parameter_diagnostics'];forecasts=ev['forecast']['rows']
 if set(functions)!=set(FUNCTIONALS) or set(coordinates)!={f'q_{i}' for i in range(1012)} or len(forecasts)!=4 or {(r['horizon'],r['group']) for r in forecasts}!={(1,g) for g in range(4)}:raise ValueError('Full1012/14/4family missing')
 health=ev['chain_count']==4 and fit['retained_divergences']==0 and all(all(finite(d[k]) for k in ['rhat','bulk_ess','tail_ess']) and 0<d['rhat']<=1.01 and min(d['bulk_ess'],d['tail_ess'])>=400 for d in [*functions.values(),*coordinates.values()])
 if fit.get('healthy') is not health:raise ValueError('Reported health differs from independent fullfamily gate')
 result=precision_screen(dict(fit,healthy=health),.02,names=list(FUNCTIONALS),require_forecast=True)
 return result['pass']


def validate_current_report(spec,report,fixture):
 """Read-only schema/target check; not independent-replicate admission by itself."""
 from continuation_comparison import norm
 if report.get('arm')!=ARM or report.get('model')!='flow' or report.get('coordinates')!='mixed_slopes':raise ValueError('Wrong current worker recipe')
 if report['settings']!=dict(chains=4,warmup=1000,threads=1,block_size=32):raise ValueError('Current worker settings differ')
 if report['seed']!=spec['sampler_seed'] or report['predictive_seed']!=spec['prediction_seed'] or spec['prediction_seed']!=spec['sampler_seed']+130000:raise ValueError('Candidate streams differ')
 if norm(report['bindings'])!=norm(spec['worker_bindings']):raise ValueError('Pinned worker sources/runtime differ')
 if norm(report['bindings']).get(str(Path(spec['fixture']).resolve()).casefold())!=spec['fixture_sha256']:raise ValueError('Worker fixture binding differs')
 if report['initial_positions']!=fixture['data']['initial_positions']:raise ValueError('Physical starts differ')
 precision=report['precision_plan']
 if precision['tiers']!=list(TIERS) or precision['names']!=list(FUNCTIONALS) or precision['forecast_rows']!=4 or precision['threshold']!=.02:raise ValueError('Firstpass/fullfamily policy differs')
 parity=report.get('parity',{})
 if parity.get('passed') is not True or parity.get('jax_enable_x64') is not True or parity.get('normalized_canonical_jacobian_value_and_gradient') is not True or not parity.get('cases'):raise ValueError('Independent normalized runtime parity missing')
 if report['hardware_control']['realized_cpus']!=[0]:raise ValueError('Worker CPU policy differs')
 target=target_crosswalk(fixture,spec['predictive_contract'])
 if target['bank_posterior_sha256']!=spec['bank_posterior_sha256']:raise ValueError('Candidate differs from bank posterior')
 return target


def selected_endpoints(report):
 result={};forecast=next(r for r in report['evaluation']['forecast']['rows'] if (r['horizon'],r['group'])==(1,0))
 for name in (*PARAMETERS,'observed_group0_h1'):
  row=forecast if name=='observed_group0_h1' else report['evaluation']['functionals'][name]
  bounds=[row['lower'],row['upper']] if name=='observed_group0_h1' else row['interval_90']
  for j,p in enumerate((.05,.95)):
   result[f'{name}_{p}']=dict(estimate=bounds[j],mcse=row['endpoint_mcse'][j],probability=p,scale='native',distribution_id=name,estimator='selected worker simulated observed quantile' if name=='observed_group0_h1' else 'selected worker empirical parameter quantile')
 return result


def validate_retention(spec,report,fixture):
 attempts=report['attempts'];tiers=[r['draws'] for r in attempts]
 if not tiers or tiers!=list(TIERS[:len(tiers)]):raise ValueError('Attempt sequence differs')
 from continuation_comparison import validate_raw_starts
 from masked_market_comparison_execute import tail_field
 from flow_mixed_coordinates import to_mixed
 import numpy as np
 calls=report['warmup_target_calls'];checks=[];previous=0
 for index,attempt in enumerate(attempts):
  tier=attempt['draws'];folder=Path(spec['worker_directory'])/f'draws-{tier}';fit_path=folder/'fit-report.json';raw=folder/'python-pymc-flow-raw.json'
  if str(fit_path.resolve()) not in spec['artifact_hashes'] or str(raw.resolve()) not in spec['artifact_hashes']:raise ValueError('Unbound attempted report/raw')
  fit=load(fit_path);passed=gate(fit)
  if fit['draws']!=tier or passed!=attempt['screen']['pass'] or passed and index!=len(attempts)-1:raise ValueError('Firstpassing tier mismatch')
  screen=attempt['screen']
  if set(screen['parameter_functionals'])!=set(FUNCTIONALS) or screen['forecast_rows']!=4 or screen['threshold']!=.02:raise ValueError('Attempt stopping family differs')
  validate_raw_starts(raw,fixture['data']['initial_positions'])
  if tail_field(raw,'adapted_metadata')!=report['adapted_metadata']:raise ValueError('Retained adaptation changed')
  np.testing.assert_array_equal(np.asarray(tail_field(raw,'sampling_initial_positions')),to_mixed(np.asarray(fixture['data']['initial_positions']),fixture['data']))
  if attempt['added_draws']!=tier-previous:raise ValueError('Retained prefix gap')
  calls+=attempt['added_target_calls']
  if calls!=attempt['cumulative_target_calls']:raise ValueError('Cumulative callback accounting differs')
  checks.append(dict(draws=tier,pass_gate=passed));previous=tier
 if calls!=report['total_target_calls'] or calls!=report['session_progress_before_close']['target_calls'] or report['session_progress_before_close']['completed_transitions']!=[1000+tiers[-1]]*4:raise ValueError('Terminal callback/transition work differs')
 for key in ('evaluation','retained_divergences'):
  if report.get(key)!=fit.get(key):raise ValueError('Final report differs from selected last fit-report: '+key)
 if selected_endpoints(report)!=selected_endpoints(fit):raise ValueError('Final endpoints differ from selected last fit-report')
 final=gate(report)
 if final!=report['precision_pass'] or final!=checks[-1]['pass_gate'] or report['draws']!=tiers[-1] or not final and tiers[-1]!=8000:raise ValueError('Terminal gate or unsuccessful stop differs')
 return dict(selected_tier=tiers[-1],attempt_checks=checks,healthy=report['healthy'],precision_pass=final,outcome='usable' if final else 'precision_or_health_failed',endpoints=selected_endpoints(report))


def normalize(spec):
 """One declared fresh repetition; failures retain identity and separate cost scopes."""
 output=dict(schema='current_mixed_workflow_candidate_v1',id=spec['id'],qualified=False,outcome='invalid_or_missing',endpoints={},policy='first-passing-1000-2000-4000-8000',costs=dict(wrapper_seconds=None,worker_seconds=None,scope='Separate measurements; never sum worker time into wrapper total'))
 try:
  status=load(spec['controller_status']);output['original_controller_status']=status;output['terminal_outcome']=status.get('status')
  outer=status.get('elapsed_seconds')
  if finite(outer) and outer>=0:output['costs']['wrapper_seconds']=outer
  if status.get('id')!=spec['controller_id']:raise ValueError('Controller identity differs')
  required=[spec[k] for k in ['report','fixture','controller_status','hardware','bank_plan','pilot_plan','analysis_intent']]
  if any(str(Path(p).resolve()) not in spec['artifact_hashes'] for p in required):raise ValueError('Missing required frozen provenance artifact')
  for path,h in spec['artifact_hashes'].items():
   if sha(path)!=h:raise ValueError('Frozen candidate artifact changed')
  report=load(spec['report']);seconds=report.get('end_to_end_seconds')
  if finite(seconds) and seconds>=0:output['costs']['worker_seconds']=seconds
  fixture=load(spec['fixture'])
  if sha(spec['fixture'])!=spec['fixture_sha256']:raise ValueError('Fixture hash differs')
  output['target_crosswalk']=validate_current_report(spec,report,fixture)
  streams=[spec[k] for k in ['sampler_seed','initialization_seed','prediction_seed']]
  excluded={c[k] for path in [spec['bank_plan'],spec['pilot_plan']] for c in load(path)['cells'] for k in ['seed','init_seed','predictive_seed']}
  excluded.add(load(spec['analysis_intent'])['analysis_policy']['bootstrap_seed'])
  if any(type(s)is not int or not 0<=s<2**32 for s in streams) or len(set(streams))!=3 or set(streams)&excluded:raise ValueError('Fresh candidate streams collide')
  from masked_market_comparison_plan import dispersed_starts
  if fixture['data']['initial_positions']!=dispersed_starts(1000,4,fixture['data']['rho'],spec['initialization_seed']):raise ValueError('Fresh initialization stream does not reproduce starts')
  output['streams']=dict(sampler_seed=spec['sampler_seed'],initialization_seed=spec['initialization_seed'],prediction_seed=spec['prediction_seed'])
  from asof_rolling_execute import validate_hardware
  h=load(spec['hardware']);validate_hardware(h,spec['command'],status['returncode'],spec['timeout_seconds'])
  if report.get('status')!='completed':output['outcome']='worker_failed';return output
  output.update(validate_retention(spec,report,fixture))
  final=output['precision_pass']
  if final:validate_success_terminal(status,h)
 except Exception as exc:output.update(outcome='invalid_or_missing',error=f'{type(exc).__name__}: {exc}',endpoints={})
 return output


def validate_success_terminal(status,hardware):
 if status.get('success') is not True or type(status.get('returncode')) is not int or status['returncode']!=0 or hardware.get('status')!='completed':raise ValueError('Worker pass not admitted by successful completed outer execution')


def collect(specs):
 if len({s['id'] for s in specs})!=len(specs):raise ValueError('Duplicate intended candidate IDs')
 streams=[s.get(k) for s in specs for k in ('sampler_seed','initialization_seed','prediction_seed')]
 if any(type(s) is not int or not 0<=s<2**32 for s in streams) or len(set(streams))!=len(streams):raise ValueError('All intended candidate streams must be globally distinct uint32 integers')
 return dict(expected=len(specs),outcomes=[normalize(s) for s in specs],qualified=False,bank_comparison_performed=False)
