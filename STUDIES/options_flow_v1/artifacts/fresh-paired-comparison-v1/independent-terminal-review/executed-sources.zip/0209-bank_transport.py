"""Read-only actual bank transport; explicit target and endpoint contract required."""
import json,hashlib,math
from pathlib import Path
PARAMS=('beta_bar','tau','mu_h','sigma_h','h_terminal','observed_group0_h1')
FAMILY={f'{n}_{p}':dict(distribution_id=n,probability=p,kind='predictive' if n==PARAMS[-1] else 'parameter') for n in PARAMS for p in (.05,.95)}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def transport(pin,*,target_sha256,endpoints,indices):
 roles=['intent','bank','status','audit','analysis','audit_provenance','analysis_plan','grid','manifest']
 if not isinstance(pin,dict) or any(not isinstance(pin.get(k),str) or not pin[k] for k in roles) or not isinstance(pin.get('bindings'),dict) or any(pin[k] not in pin['bindings'] for k in roles):raise ValueError('Every referenced artifact must be pinned')
 if endpoints!=FAMILY or target_sha256!=pin['target_sha256']:raise ValueError('Exact target/endpoint contract mismatch')
 if any(sha(p)!=h for p,h in pin['bindings'].items()):raise ValueError('Pinned artifact drift')
 intent=read(pin['intent']);bank=read(pin['bank']);status=read(pin['status']);audit=read(pin['audit']);analysis=read(pin['analysis'])
 provenance=read(pin['audit_provenance'])
 if provenance['audit_sha256']!=sha(pin['audit']) or provenance['analysis_plan_sha256']!=sha(pin['analysis_plan']) or status['plan_sha256']!=sha(pin['analysis_plan']):raise ValueError('Audit/status plan lineage mismatch')
 inventory={str(Path(k).resolve()).casefold():v['sha256'] for k,v in audit['inventory'].items()}
 for role in ['bank','analysis','grid']:
  if inventory.get(str(Path(pin[role]).resolve()).casefold())!=sha(pin[role]):raise ValueError('Unrelated audit inventory')
 plan=read(pin['analysis_plan']);planbindings={str(Path(k).resolve()).casefold():v for k,v in plan['bindings'].items()}
 if planbindings.get(str(Path(pin['manifest']).resolve()).casefold())!=sha(pin['manifest']) or plan['prefit_intent_sha256']!=sha(pin['intent']):raise ValueError('Manifest/intent plan lineage mismatch')
 if audit.get('integrity_pass') is not True or status.get('reference_bank_resolved') is not True or status.get('returncode')!=0 or analysis.get('integrity_pass') is not True:raise ValueError('Bank terminal admission unresolved')
 if status['result_sha256']!=sha(pin['analysis']) or bank['target_sha256']!=target_sha256 or intent['posterior_sha256']!=target_sha256 or intent['endpoints']!=endpoints:raise ValueError('Bank provenance/target mismatch')
 if bank['status']!='numerically_resolved_under_declared_checks' or bank['expected_fits']!=64 or bank['recorded_fits']!=64 or bank['reasons']:raise ValueError('Incomplete bank')
 names=list(endpoints);vectors=bank['joint_bootstrap_endpoints']
 if len(vectors)!=30000 or not indices or any(type(i)is not int or not 0<=i<len(vectors) for i in indices):raise ValueError('Invalid frozen vector selection')
 selected=[]
 for i in indices:
  v=vectors[i]
  if set(v)!=set(names) or any(type(x)not in (int,float) or not math.isfinite(x) for x in v.values()):raise ValueError('Malformed joint vector')
  selected.append(dict(v))
 eps={n:bank['endpoints'][n]['numerical_half_width'] for n in names}
 if any(type(x)not in (int,float) or not math.isfinite(x) or x<0 for x in eps.values()):raise ValueError('Invalid numerical envelope')
 # Existing audited analyze takes maximum error over point and ALL bootstrap rows;
 # this global envelope conservatively applies to any selected subset.
 return dict(endpoint_names=names,bank_vectors=selected,numerical_halfwidth=eps,target_sha256=target_sha256,qualified=False,scope='Approximate jointly bootstrapped reference; global maximum numerical estimates, not exact truth or coverage certificate')
