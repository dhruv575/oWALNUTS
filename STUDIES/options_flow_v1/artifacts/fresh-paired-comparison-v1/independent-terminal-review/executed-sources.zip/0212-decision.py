"""Prospective arithmetic decision policy; approximate bootstrap, no sampling."""
import math
import numpy as np
from scipy.stats import beta

def analyze(expected_pairs,arms,endpoint_names,bank_vectors,counts,bank_indices,widths,numerical_halfwidth):
 names=list(endpoint_names);ids=list(expected_pairs);B=len(bank_indices)
 if len(ids)!=36 or len(set(ids))!=36 or len(names)!=12 or len(set(names))!=12 or set(arms)!={'public','reference'}:raise ValueError('Fixed36pairs/twoarms/12endpoints required')
 #48equal-budget checks:24two-sided mean checks,24one-sided RMS checks.
 mean_tail=.05/(48*2);rms_tail=.05/48
 if B*mean_tail<20 or len(counts)!=B:raise ValueError('At least20 tail observations for most stringent tail required')
 w=np.asarray([widths[n] for n in names],float);eps=np.asarray([numerical_halfwidth[n] for n in names],float)/w
 if not np.isfinite(w).all() or (w<=0).any() or not np.isfinite(eps).all() or (eps<0).any():raise ValueError('Finite positive pinned widths/numerical errors required')
 arrays={};reliability={};unresolved=[];outcomes={}
 for arm in ['public','reference']:
  records=arms[arm]
  if len(records)!=36 or {r['id'] for r in records}!=set(ids):raise ValueError('Complete intended family including explicit missing outcomes required')
  byid={r['id']:r for r in records};ys=[];usable=[];cost=[]
  for identity in ids:
   r=byid[identity];ok=r.get('usable') is True
   if type(r.get('usable')) is not bool:raise ValueError('Explicit usability required')
   seconds=r.get('seconds')
   if r.get('status') in ('missing','unstarted') or type(seconds) not in (int,float) or not math.isfinite(seconds) or seconds<0:unresolved.append(f'{arm}:{identity}:unknown/unstarted');seconds=0.
   if ok:
    e=r['endpoints']
    if set(e)!=set(names) or not all(type(v) in (int,float) and math.isfinite(v) for v in e.values()):raise ValueError('Malformed usable endpoints')
    ys.append([e[n] for n in names])
   else:ys.append([0.]*12)
   usable.append(ok);cost.append(seconds)
  u=np.asarray(usable);k=int(u.sum());lower=0. if k==0 else float(beta.ppf(.025,k,37-k))
  reliability[arm]=dict(successes=k,intended=36,lower97_5=lower,pass_gate=lower>.90,total_cost=sum(cost),cost_per_intended=sum(cost)/36,cost_per_success=sum(cost)/k if k else None)
  arrays[arm]=(np.asarray(ys),u,np.asarray(cost));outcomes[arm]=[dict(id=i,usable=bool(u[j]),status=byid[i].get('status')) for j,i in enumerate(ids)]
 stats=np.empty((B,2,12,2));ratios=np.empty(B);undefined=False
 for i,(row,index) in enumerate(zip(counts,bank_indices)):
  if not isinstance(row,dict) or set(row)-set(ids) or any(type(v)is not int or v<0 for v in row.values()) or sum(row.values())!=36:raise ValueError('Fixed paired resample mass36 required')
  if type(index)is not int or not 0<=index<len(bank_vectors):raise ValueError('Invalid shared reference index')
  v=bank_vectors[index]
  if set(v)!=set(names) or not all(type(x)in(int,float) and math.isfinite(x) for x in v.values()):raise ValueError('Malformed bank vector')
  bank=np.asarray([v[n] for n in names]);c=np.asarray([row.get(k,0) for k in ids]);costs=[]
  for j,arm in enumerate(['public','reference']):
   y,u,cost=arrays[arm];mass=int(c[u].sum())
   if not mass:undefined=True;stats[i,j]=np.nan;costs.append(float('nan'));continue
   weights=c[u]/mass;error=(y[u]-bank)/w;stats[i,j,:,0]=weights@error;stats[i,j,:,1]=np.sqrt(weights@(error**2));costs.append(float(c@cost)/mass)
  ratios[i]=costs[1]/costs[0] if costs[0]>0 else float('nan')
 if undefined or not np.isfinite(ratios).all():unresolved.append('A resample has zero usable weight/invalid cost ratio')
 accuracy={}
 for j,arm in enumerate(['public','reference']):
  checks={}
  for k,name in enumerate(names):
   if not np.isfinite(stats[:,j,k]).all():checks[name]=dict(pass_gate=False,interval=None);continue
   mean=np.quantile(stats[:,j,k,0],[mean_tail,1-mean_tail])+np.array([-eps[k],eps[k]])
   rms=float(np.quantile(stats[:,j,k,1],1-rms_tail))+eps[k]
   checks[name]=dict(mean_interval=mean.tolist(),rms_upper=rms,pass_gate=bool(mean[0]>=-.02 and mean[1]<=.02 and rms<=.04))
  accuracy[arm]=dict(checks=checks,pass_gate=all(c['pass_gate'] for c in checks.values()))
 interval=np.quantile(ratios,[.025,.975]).tolist() if np.isfinite(ratios).all() else None
 speed=bool(not unresolved and interval is not None and interval[0]>1.25 and all(r['pass_gate'] for r in reliability.values()) and all(r['pass_gate'] for r in accuracy.values()))
 return dict(reliability=reliability,accuracy=accuracy,runtime_ratio_interval=interval,speed_gate=speed,unresolved_reasons=unresolved,outcomes=outcomes,qualified=False,policy=dict(mean_tail=mean_tail,rms_tail=rms_tail,replicates=B,reliability_family='95%twoarm Bonferroni CP',accuracy_family='Separate approximate95%48check bootstrap family',runtime_family='Separate approximate95%paired ratio of totalcost/success, failures costed',overall_joint95_claim=False),limitations='Arithmetic gates only; bootstrap coverage unproven, reference approximate, accuracy conditional on usable candidates; unstarted/unknown costs forbid speed claim.')
