"""Explicit resample statistics only. No RNG, confidence level or qualification."""
import math
from reference_bank import shared_reference_errors

def compare(expected_ids,candidates,endpoint_names,bank_vectors,candidate_counts,bank_indices,numerical_halfwidth):
    """Condition statistics on usable candidates, retaining intended outcomes.

    candidate_counts is one ID->nonnegative integer multiplicity map per outer
    replicate; bank_indices supplies ONE shared bank vector index per replicate.
    An unusable candidate's count is reported but excluded from conditional
    statistics. A replicate with zero usable weight has undefined statistics.
    numerical_halfwidth is a deterministic per-endpoint bound/estimate supplied
    by the caller, kept separate from stochastic bank vectors and candidate MCSE.
    """
    ids=list(expected_ids);names=list(endpoint_names)
    if not ids or len(set(ids))!=len(ids) or any(not isinstance(x,str) or not x for x in ids):raise ValueError('Unique intended IDs required')
    if len(names)!=12 or len(set(names))!=12 or any(not isinstance(k,str) or not k for k in names):raise ValueError('Exactly12 distinct prespecified endpoint names required')
    def vector(v,nonnegative=False):
        return isinstance(v,dict) and set(v)==set(names) and all(type(x) in (int,float) and math.isfinite(x) and (not nonnegative or x>=0) for x in v.values())
    if not vector(numerical_halfwidth,True) or not bank_vectors or any(not vector(v) for v in bank_vectors):raise ValueError('Finite full bank vectors and numerical halfwidth required')
    if len(candidate_counts)!=len(bank_indices) or not candidate_counts:raise ValueError('Aligned explicit outer replicates required')
    supplied={}
    for c in candidates:
        if c.get('id') not in ids or c['id'] in supplied or type(c.get('usable')) is not bool:raise ValueError('Duplicate/extra/malformed candidate')
        if c['usable'] and not vector(c.get('endpoints')):raise ValueError('Usable candidate needs all finite endpoints')
        supplied[c['id']]=c
    outcomes=[dict(id=k,usable=supplied.get(k,{}).get('usable',False),status=supplied[k].get('status','unspecified') if k in supplied else 'missing') for k in ids]
    usable=[k for k in ids if k in supplied and supplied[k]['usable']]
    replicates=[]
    for counts,index in zip(candidate_counts,bank_indices):
        if not isinstance(counts,dict) or set(counts)-set(ids) or any(type(v)is not int or v<0 for v in counts.values()) or sum(counts.values())<=0:raise ValueError('Positive integer multiplicity over intended IDs required')
        if type(index)is not int or not 0<=index<len(bank_vectors):raise ValueError('One valid bank-vector index per replicate required')
        mass=sum(counts.get(k,0) for k in usable);total=sum(counts.values())
        record=dict(bank_index=index,intended_weight=total,usable_weight=mass,excluded_unusable_weight=total-mass,statistics=None)
        if mass:
            errors=shared_reference_errors([supplied[k]['endpoints'] for k in usable],bank_vectors[index]);stats={}
            for name in names:
                terms=[(counts.get(k,0),error[name]) for k,error in zip(usable,errors) if counts.get(k,0)]
                mean=math.fsum((weight/mass)*value for weight,value in terms)
                rms=math.hypot(*(math.sqrt(weight/mass)*value for weight,value in terms))
                epsilon=numerical_halfwidth[name]
                if not all(math.isfinite(v) for v in [mean,rms,mean-epsilon,mean+epsilon,rms+epsilon]):raise ValueError('Nonfinite derived statistic')
                stats[name]=dict(signed_mean_error=mean,rms_error=rms,numerical_halfwidth_estimate=epsilon,numerical_bound_certified=False,signed_mean_estimated_numerical_envelope=[mean-epsilon,mean+epsilon],rms_estimated_numerical_envelope=[max(0.,rms-epsilon),rms+epsilon])
            record['statistics']=stats
        replicates.append(record)
    return dict(expected_candidates=len(ids),usable_candidates=len(usable),outcomes=outcomes,replicates=replicates,qualified=False,reliability_claim=False,conditioning='Endpoint statistics condition on usable candidate weight; missing/failed intended candidates remain in outcomes and excluded-weight counts.',numerical_scope='Deterministic Lipschitz envelopes conditional on supplied numerical halfwidth; estimated input remains estimated. No candidate MCSE added and no confidence interval computed.')
