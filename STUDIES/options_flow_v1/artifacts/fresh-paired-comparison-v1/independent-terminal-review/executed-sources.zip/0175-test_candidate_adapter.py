"""QUEUED ONLY: no tests executed during the bank timing hold."""
import copy,json,sys
from pathlib import Path
import pytest
STUDY=Path(__file__).resolve().parents[2]/'STUDIES/options_flow_v1'
sys.path.insert(0,str(STUDY))
import candidate_adapter as a


def saved_contract():
 root=STUDY/'artifacts/optimized-mixed-comparison-v1';report_path=root/'pair0-ow_mixed/python-pymc-flow-report.json';fixture_path=STUDY/'artifacts/python-flow-long-v1/fixture.json'
 report=json.loads(report_path.read_text());fixture=json.loads(fixture_path.read_text())
 from posterior_resource.controller import posterior
 spec=dict(fixture=str(fixture_path),fixture_sha256=a.sha(fixture_path),sampler_seed=report['seed'],prediction_seed=report['predictive_seed'],worker_bindings=report['bindings'],bank_posterior_sha256=posterior(fixture),predictive_contract='one-step observed StudentT; actual supplied future flow')
 return spec,report,fixture


def test_preserved_actual_report_schema_only():
 # Historical same-start evidence validates schema only, never fresh-replicate admission.
 spec,report,fixture=saved_contract();cross=a.validate_current_report(spec,report,fixture)
 assert cross['bank_posterior_sha256']==spec['bank_posterior_sha256']
 assert a.gate(report) is True and len(a.selected_endpoints(report))==12
 for item in a.selected_endpoints(report).values():assert item['probability'] in [.05,.95]


@pytest.mark.parametrize('field',['source','tierpolicy','parity','target','start'])
def test_saved_report_rejects_identity_mutations(field):
 spec,report,fixture=saved_contract();report=copy.deepcopy(report)
 if field=='source':report['bindings']={}
 elif field=='tierpolicy':report['precision_plan']['tiers']=[8000]
 elif field=='parity':report['parity']['passed']=False
 elif field=='target':spec['bank_posterior_sha256']='wrong'
 else:report['initial_positions'][0][0]+=1
 with pytest.raises(ValueError):a.validate_current_report(spec,report,fixture)


def test_target_crosswalk_excludes_truth_starts_and_future_labels_only():
 spec,report,fixture=saved_contract();other=copy.deepcopy(fixture)
 baseline=a.target_crosswalk(fixture,spec['predictive_contract']);other['data']['initial_positions'][0][0]+=1
 other['truth']=['changed'];other['holdout']['y']=[[999]*4]
 assert a.target_crosswalk(other,spec['predictive_contract'])==baseline
 other['holdout']['x'][0][0]+=.1
 assert a.target_crosswalk(other,spec['predictive_contract'])!=baseline


@pytest.mark.parametrize('field',['rhat','coordinate','functional','forecast'])
def test_fullfamily_gate_not_replaced_by12endpoints(field):
 spec,report,fixture=saved_contract();report=copy.deepcopy(report)
 if field=='rhat':report['evaluation']['canonical_parameter_diagnostics']['q_999']['rhat']=0
 elif field=='coordinate':report['evaluation']['canonical_parameter_diagnostics'].pop('q_999')
 elif field=='functional':report['evaluation']['functionals'].pop('beta_3')
 else:report['evaluation']['forecast']['rows'][3]['group']=0
 with pytest.raises(ValueError):a.gate(report)


def test_failure_denominator_retains_known_outer_cost(tmp_path):
 status=tmp_path/'status.json';status.write_text(json.dumps(dict(id='controller',status='budgeted_timeout',elapsed_seconds=1800)))
 spec=dict(id='candidate',controller_id='controller',controller_status=str(status),sampler_seed=1,initialization_seed=2,prediction_seed=130001)
 result=a.collect([spec]);row=result['outcomes'][0]
 assert result['expected']==1 and row['outcome']=='invalid_or_missing' and row['costs']['wrapper_seconds']==1800
 assert row['costs']['worker_seconds'] is None and not row['endpoints'] and not result['qualified']


def test_preserved_actual_firstpass_retention_schema_only():
 spec,report,fixture=saved_contract();root=STUDY/'artifacts/optimized-mixed-comparison-v1/pair0-ow_mixed'
 paths=[root/f'draws-{attempt["draws"]}'/name for attempt in report['attempts'] for name in ['fit-report.json','python-pymc-flow-raw.json']]
 spec.update(worker_directory=str(root),artifact_hashes={str(p.resolve()):a.sha(p) for p in paths})
 result=a.validate_retention(spec,report,fixture)
 assert result['outcome']=='usable' and result['selected_tier']==report['draws'] and len(result['endpoints'])==12
 bad=copy.deepcopy(report);bad['attempts'][-1]['added_draws']+=1
 with pytest.raises(ValueError,match='prefix gap'):a.validate_retention(spec,bad,fixture)


@pytest.mark.parametrize('bad',[True,-1,2**32,None,1.5])
def test_global_stream_validation_precedes_normalization(monkeypatch,bad):
 spec=dict(id='a',sampler_seed=1,initialization_seed=2,prediction_seed=130001)
 spec['initialization_seed']=bad
 monkeypatch.setattr(a,'normalize',lambda _:pytest.fail('Must reject before any success denominator'))
 with pytest.raises(ValueError,match='globally distinct'):a.collect([spec])


def test_cross_candidate_cross_role_collision_rejected_before_normalization(monkeypatch):
 specs=[dict(id='a',sampler_seed=1,initialization_seed=2,prediction_seed=130001),dict(id='b',sampler_seed=3,initialization_seed=130001,prediction_seed=130003)]
 monkeypatch.setattr(a,'normalize',lambda _:pytest.fail('Must reject before normalization'))
 with pytest.raises(ValueError,match='globally distinct'):a.collect(specs)


@pytest.mark.parametrize('success,returncode,hardware_status',[(False,0,'completed'),(True,1,'worker-failed'),(True,0,'worker-failed'),(True,False,'completed')])
def test_usable_requires_successful_completed_outer_execution(success,returncode,hardware_status):
 with pytest.raises(ValueError,match='successful completed'):
  a.validate_success_terminal(dict(success=success,returncode=returncode),dict(status=hardware_status))


def test_usable_terminal_exact_success():
 a.validate_success_terminal(dict(success=True,returncode=0),dict(status='completed'))


@pytest.mark.parametrize('field',['evaluation','divergences'])
def test_final_summary_must_equal_selected_fit_report(field):
 spec,report,fixture=saved_contract();root=STUDY/'artifacts/optimized-mixed-comparison-v1/pair0-ow_mixed'
 paths=[root/f'draws-{attempt["draws"]}'/name for attempt in report['attempts'] for name in ['fit-report.json','python-pymc-flow-raw.json']]
 spec.update(worker_directory=str(root),artifact_hashes={str(p.resolve()):a.sha(p) for p in paths})
 bad=copy.deepcopy(report)
 if field=='evaluation':bad['evaluation']['functionals']['beta_bar']['interval_90'][0]+=.0000001
 else:bad['retained_divergences']=1
 with pytest.raises(ValueError,match='selected last fit-report'):a.validate_retention(spec,bad,fixture)
