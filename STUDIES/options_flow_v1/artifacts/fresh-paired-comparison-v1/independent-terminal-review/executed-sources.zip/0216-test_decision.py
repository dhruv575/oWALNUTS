import copy
import pytest
from decision import analyze
N=[f'e{i}' for i in range(12)];IDS=[str(i) for i in range(36)]
def setup():
 arms={a:[dict(id=i,usable=True,status='completed',seconds=cost,endpoints=dict.fromkeys(N,0.)) for i in IDS] for a,cost in [('public',1.),('reference',2.)]}
 return arms,[dict.fromkeys(N,-.005),dict.fromkeys(N,.005)], [dict.fromkeys(IDS,1)]*38400,[i%2 for i in range(38400)]
def test_full_policy_shared_bank_and_cost_success():
 a,b,c,i=setup();r=analyze(IDS,a,N,b,c,i,dict.fromkeys(N,1.),dict.fromkeys(N,.001))
 assert r['speed_gate'] and r['runtime_ratio_interval']==[2.,2.]
 assert r['reliability']['public']['lower97_5']>.9
 assert r['accuracy']['public']['checks']['e0']['mean_interval']==pytest.approx([-.006,.006])
 assert not r['policy']['overall_joint95_claim']
def test_failures_are_costed_and_block_reliability():
 a,b,c,i=setup();a['public'][0].update(usable=False,status='timeout',seconds=100.)
 r=analyze(IDS,a,N,b,c,i,dict.fromkeys(N,1.),dict.fromkeys(N,0.))
 assert r['reliability']['public']['total_cost']==135 and r['reliability']['public']['cost_per_success']==135/35
 assert not r['speed_gate'] and not r['reliability']['public']['pass_gate']
def test_unknown_unstarted_prevents_speed():
 a,b,c,i=setup();a['public'][0].update(usable=False,status='unstarted',seconds=None)
 r=analyze(IDS,a,N,b,c,i,dict.fromkeys(N,1.),dict.fromkeys(N,0.));assert not r['speed_gate'] and r['unresolved_reasons']
def test_tail_resolution_no_silent_small_bootstrap():
 a,b,c,i=setup()
 with pytest.raises(ValueError,match='tail'):analyze(IDS,a,N,b,c[:30000],i[:30000],dict.fromkeys(N,1.),dict.fromkeys(N,0.))
