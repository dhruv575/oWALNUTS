from pathlib import Path
import copy,json
import pytest
import bank_transport as t
PIN=Path(__file__).with_name('actual-bank-pin.json')

def test_actual_joint_vector_transport():
 p=t.read(PIN);r=t.transport(p,target_sha256=p['target_sha256'],endpoints=t.FAMILY,indices=[0,29999]);assert len(r['bank_vectors'])==2 and set(r['numerical_halfwidth'])==set(t.FAMILY)
 assert r['numerical_halfwidth']['observed_group0_h1_0.05']>0

@pytest.mark.parametrize('mutation',['missing_binding','target','endpoint','index','hash'])
def test_adversarial_pin_rejections(mutation):
 p=t.read(PIN);target=p['target_sha256'];family=copy.deepcopy(t.FAMILY);indices=[0]
 if mutation=='missing_binding':p['bindings'].pop(p['bank'])
 if mutation=='target':target='unrelated'
 if mutation=='endpoint':family['tau_0.05']['distribution_id']='log_tau'
 if mutation=='index':indices=[True]
 if mutation=='hash':p['bindings'][p['bank']]='0'*64
 with pytest.raises(ValueError):t.transport(p,target_sha256=target,endpoints=family,indices=indices)

def test_unrelated_passing_audit_rejected(tmp_path):
 p=t.read(PIN);a=t.read(p['audit']);a['inventory']={};fake=tmp_path/'audit.json';fake.write_text(json.dumps(a));prov=t.read(p['audit_provenance']);prov['audit_sha256']=t.sha(fake);pp=tmp_path/'provenance.json';pp.write_text(json.dumps(prov))
 p.update(audit=str(fake),audit_provenance=str(pp));p['bindings'].update({str(fake):t.sha(fake),str(pp):t.sha(pp)})
 with pytest.raises(ValueError,match='Unrelated audit'):t.transport(p,target_sha256=p['target_sha256'],endpoints=t.FAMILY,indices=[0])
