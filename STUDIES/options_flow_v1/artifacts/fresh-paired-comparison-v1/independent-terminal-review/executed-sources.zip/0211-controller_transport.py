"""Full controller-to-decision bridge. No sampling; immutable evidence required."""
import json,math,hashlib
from pathlib import Path
from decision import analyze
from bank_transport import transport,read,sha,FAMILY

def terminal_to_arms(plan,terminal,cost,pairs,normalize):
 if terminal['expected']!=72 or len(plan['cells'])!=72 or len(pairs)!=36 or len({p['id'] for p in pairs})!=36:raise ValueError('36pairs72intended required')
 cells={c['id']:c for c in plan['cells']};rows={r['controller']['id']:r for r in terminal['outcomes']}
 if len(rows)!=72 or len(terminal['outcomes'])!=72 or set(rows)!=set(cells):raise ValueError('Terminal denominator differs')
 mapped=[p[a] for p in pairs for a in ['public','reference']]
 if len(set(mapped))!=72 or set(mapped)!=set(cells):raise ValueError('Exact paired mapping required')
 total=cost['total_seconds_including_terminal_serialization'];base=[r['full_cell_seconds'] for r in rows.values()]
 if any(type(x)not in(int,float) or not math.isfinite(x) or x<0 for x in [total,*base]) or total+1e-6<sum(base):raise ValueError('Invalid full cost reconciliation')
 overhead=max(0.,total-sum(base))/72;arms={'public':[],'reference':[]};flags=[]
 if cost.get('total_budget_unresolved') is not False or terminal.get('budget_status')!='within_admission_budget':flags.append('Global budget unresolved')
 for pair in pairs:
  for arm in arms:
   cid=pair[arm];cell=cells[cid];row=rows[cid];status=row['controller']['status']
   if cell['backend']!=arm:raise ValueError('Pair/backend mismatch')
   if status not in ('completed','worker_failed','failed','unattempted','missing','unstarted') and not status.startswith('unattempted_'):raise ValueError('Unknown controller status')
   if row['controller'].get('integrity_pass') is False:raise ValueError('Controller integrity failure')
   normalized=row['normalized']
   if normalized.get('outcome')=='usable':
    verified=normalize(cell)
    if verified!=normalized:raise ValueError('Normalized evidence changed')
    if normalized['id']!=cid or normalized['streams']!={k:cell[k] for k in ['sampler_seed','initialization_seed','prediction_seed']}:raise ValueError('Candidate identity/stream mismatch')
   unknown=status in ('missing','unstarted') or status.startswith('unattempted')
   if unknown:flags.append(f'{cid}:unattempted')
   arms[arm].append(dict(id=pair['id'],usable=normalized.get('outcome')=='usable' and not unknown,status='unstarted' if unknown else status,seconds=row['full_cell_seconds']+overhead,endpoints=endpoint_values(normalized['endpoints']) if normalized.get('outcome')=='usable' and not unknown else {}))
 return arms,dict(total_seconds=total,shared_overhead_seconds=max(0.,total-sum(base)),allocation='Equal shared overhead per72intended cells, including failures/unattempted; never double count components',unresolved_reasons=flags)

def execute(pin,normalize=None):
 import numpy as np
 required=['plan','terminal','terminal_cost','pair_map','counts','bank_indices','bank_pin','artifact_manifest']
 if any(pin[k] not in pin['bindings'] for k in required) or any(sha(p)!=h for p,h in pin['bindings'].items()):raise ValueError('Required immutable input binding mismatch')
 plan=read(pin['plan']);terminal=read(pin['terminal']);cost=read(pin['terminal_cost']);pairs=read(pin['pair_map'])
 if terminal['plan_sha256']!=sha(pin['plan']):raise ValueError('Terminal plan identity mismatch')
 bp=read(pin['bank_pin']);indices=np.load(pin['bank_indices'],allow_pickle=False);matrix=np.load(pin['counts'],allow_pickle=False)
 if matrix.shape!=(40000,36) or indices.shape!=(40000,) or matrix.dtype.kind not in 'iu' or indices.dtype.kind not in 'iu' or (matrix<0).any() or (matrix.sum(axis=1)!=36).any():raise ValueError('Frozen40000paired schedule shape invalid')
 bank=transport(bp,target_sha256=pin['target_sha256'],endpoints=FAMILY,indices=indices.tolist())
 if normalize is None:normalize=verified_normalizer(pin)
 arms,costs=terminal_to_arms(plan,terminal,cost,pairs,normalize)
 for arm in arms:
  for record,pair in zip(arms[arm],pairs):
   if record['usable']:
    row=next(r for r in terminal['outcomes'] if r['controller']['id']==pair[arm])
    if row['normalized']['target_crosswalk']['bank_posterior_sha256']!=pin['target_sha256']:raise ValueError('Candidate/bank target mismatch')
 rawbank=read(bp['bank']);widths={n:rawbank['endpoints'][n]['W_low'] for n in FAMILY}
 ids=[p['id'] for p in pairs];counts=({k:int(v) for k,v in zip(ids,row) if v} for row in matrix)
 # Decision expects indexed list;40000compact countmaps are modest and contain no endpoint dictionaries.
 result=analyze(ids,arms,list(FAMILY),bank['bank_vectors'],list(counts),list(range(40000)),widths,bank['numerical_halfwidth'])
 result['cost_reconciliation']=costs;result['unresolved_reasons']+=costs['unresolved_reasons']
 if costs['unresolved_reasons']:result['speed_gate']=False
 if any(sha(p)!=h for p,h in pin['bindings'].items()):raise ValueError('Postanalysis evidence drift')
 return result


def verified_normalizer(pin):
 """Production dispatch with immutable postfit artifact inventory; no fresh hash trust."""
 import sys,importlib
 manifest=read(pin['artifact_manifest'])
 if manifest['plan_sha256']!=sha(pin['plan']):raise ValueError('Artifact manifest plan mismatch')
 modules={}
 sys.path.insert(0,pin['study_directory'])
 for arm,name in [('public','candidate_adapter'),('reference','reference_adapter')]:
  path=str(Path(pin['adapter_paths'][arm]).resolve())
  if path not in pin['bindings'] or sha(path)!=pin['bindings'][path]:raise ValueError('Unbound adapter source')
  sys.path.insert(0,str(Path(path).parent))
  spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
  sys.modules[name]=module;spec.loader.exec_module(module);modules[arm]=module
 def normalize(cell):
  paths=[cell[k] for k in ('fixture','controller_status','bank_plan','pilot_plan','analysis_intent','report','hardware')]
  paths += list(Path(cell['worker_directory']).glob('draws-*/*.json'))+list(Path(cell['worker_directory']).glob('draws-*.json'))
  existing={str(Path(x).resolve()) for x in paths if Path(x).is_file()}
  hashes=manifest['cells'][cell['id']]
  if set(hashes)!=existing or any(pin['bindings'].get(p)!=h or sha(p)!=h for p,h in hashes.items()):raise ValueError('Postfit evidence missing, added or changed')
  return modules[cell['backend']].normalize(dict(cell,artifact_hashes=hashes))
 return normalize



def endpoint_values(rows):
 if set(rows)!=set(FAMILY):raise ValueError('Exact twelve endpoint family required')
 values={}
 for name,spec in FAMILY.items():
  r=rows[name]
  if r.get('scale')!='native' or r.get('probability')!=spec['probability'] or r.get('distribution_id')!=spec['distribution_id']:raise ValueError('Endpoint semantics mismatch')
  if any(type(r.get(k)) not in (int,float) or not math.isfinite(r[k]) for k in ('estimate','mcse')) or r['mcse']<0:raise ValueError('Nonfinite endpoint/MCSE')
  values[name]=r['estimate']
 return values

if __name__=='__main__':
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--pin',required=True);parser.add_argument('--out',required=True)
 args=parser.parse_args();out=Path(args.out)
 if out.exists():raise FileExistsError('No output overwrite')
 result=execute(read(args.pin))
 with out.open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
