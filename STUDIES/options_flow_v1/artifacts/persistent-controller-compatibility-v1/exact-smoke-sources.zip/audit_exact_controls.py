"""Independent saved-cell audit; descriptive replicate-bootstrap uncertainty.

Reads terminal artifacts only. Does not import the worker or numerical packages.
Bootstrap intervals are marginal percentile intervals, not simultaneous or
qualification guarantees. Fixed-length analysis retains unhealthy finite fits.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import random
import statistics

TRUTH={'normal':[-1.6448536269514722,1.6448536269514722],
       'student_t5':[-2.0150483733330233,2.0150483733330233]}


def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def quantile(values,p):
    values=sorted(values);position=p*(len(values)-1);lo=int(position);hi=min(lo+1,len(values)-1)
    return values[lo]+(values[hi]-values[lo])*(position-lo)
def finite(value):return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)


def estimates(rows,index):
    values=[r['estimate'][index] for r in rows];errors=[r['mcse'][index] for r in rows]
    truth=rows[0]['truth'][index]
    empirical=statistics.stdev(values);rms=math.sqrt(statistics.mean(s*s for s in errors))
    return dict(empirical_sd=empirical,rms_reported_mcse=rms,mcse_calibration_ratio=empirical/rms if rms else None,
        bias=statistics.mean(values)-truth,rmse=math.sqrt(statistics.mean((v-truth)**2 for v in values)))


def intervals(rows,index,seed,bootstrap=2000):
    point=estimates(rows,index);rng=random.Random(seed);samples={k:[] for k in point}
    for _ in range(bootstrap):
        replicate=[rows[rng.randrange(len(rows))] for _ in rows]
        for key,value in estimates(replicate,index).items():
            if value is not None:samples[key].append(value)
    return dict(point=point,marginal_95_percentile_intervals={k:[quantile(v,.025),quantile(v,.975)] if v else None for k,v in samples.items()},
        bootstrap_replicates=bootstrap,bootstrap_seed=seed,n=len(rows))


def audit(plan_path,results,worker_source,bootstrap=2000):
    plan_path=Path(plan_path);results=Path(results);plan=json.loads(plan_path.read_text());sha=digest(plan_path)
    failures=[];groups={};seen_seeds=set();ids=set();allrows={}
    def require(condition,message):
        if not condition:failures.append(message)
    require(plan.get('frozen') is True,'plan not frozen')
    require(plan_path.with_suffix('.sha256').read_text().strip()==sha,'plan sidecar mismatch')
    require(digest(worker_source)==plan['source_sha256'],'worker source mismatch')
    require(len(plan['cells'])==7200 and plan['replicates']==200,'expected 7200 cells/200 replicates')
    for cell in plan['cells']:
        key=cell['id'];require(key not in ids,'duplicate ID '+key);ids.add(key)
        for seed in cell['seeds']:
            require(seed not in seen_seeds,'duplicate seed '+str(seed));seen_seeds.add(seed)
        group=f"{cell['marginal']}/{cell['rho']}/{cell['policy']}";groups.setdefault(group,[]).append(key)
        started=results/(key+'-started.json');terminal=results/(key+'.json')
        if not started.exists() or not terminal.exists():failures.append('missing cell artifacts '+key);continue
        begin=json.loads(started.read_text());row=json.loads(terminal.read_text());allrows[key]=row
        require(begin.get('plan_sha256')==sha and begin.get('cell')==cell,'started identity mismatch '+key)
        require(all(row.get(k)==v for k,v in cell.items()),'terminal identity mismatch '+key)
        require(finite(row.get('seconds')) and row['seconds']>=0,'invalid elapsed cost '+key)
        require(row.get('status') in ['completed','failed'],'nonterminal status '+key)
        if row.get('status')=='failed':
            require(row.get('usable') is False and not row.get('finite_estimator'),'failed estimator counted '+key);continue
        require(row.get('finite_estimator') is True,'completed estimator flag mismatch '+key)
        require(all(finite(v) and math.isclose(v,expected,rel_tol=1e-10,abs_tol=1e-10) for v,expected in zip(row.get('truth',[]),TRUTH[cell['marginal']])) and len(row.get('truth',[]))==2,'analytic truth mismatch '+key)
        require(all(len(row.get(name,[]))==2 and all(finite(v) for v in row[name]) for name in ['estimate','mcse']),'invalid endpoint metrics '+key)
        require(all(v>=0 for v in row.get('mcse',[])),'negative MCSE '+key)
        attempts=row.get('attempts',[]);lengths=[a['draws'] for a in attempts]
        fixed=cell['policy'].startswith('fixed_')
        require(lengths==([int(cell['policy'].split('_')[1])] if fixed else plan['tiers'][:len(lengths)]),'invalid tier sequence '+key)
        require(bool(attempts),'no attempts '+key)
        if not attempts:continue
        for attempt in attempts:
            numbers=[attempt.get(k) for k in ['rhat','bulk_ess','tail_ess']]
            healthy=all(finite(v) for v in numbers) and numbers[0]<=1.01 and min(numbers[1:])>=400
            require(attempt.get('healthy')==healthy,'health computation mismatch '+key)
        width=row['estimate'][1]-row['estimate'][0]
        precise=width>0 and max(row['mcse'])<=.02*width
        require(row.get('precision_pass')==(attempts[-1]['healthy'] and precise),'terminal precision mismatch '+key)
        require(row.get('healthy')==attempts[-1]['healthy'],'terminal health flag mismatch '+key)
        require(row.get('usable')==(attempts[-1]['healthy'] if fixed else row.get('precision_pass')),'usable mismatch '+key)
        if not fixed:require(not any(a['precision_pass'] for a in attempts[:-1]) and (row['precision_pass'] or lengths[-1]==plan['tiers'][-1]),'stopping rule mismatch '+key)
    expected_files={key+'.json' for key in ids}|{key+'-started.json' for key in ids}|{'summary.json'}
    require({p.name for p in results.glob('*.json')}==expected_files,'extra or missing JSON files in results')
    reported=json.loads((results/'summary.json').read_text())
    require(reported.get('plan_sha256')==sha and reported.get('software')==plan.get('software'),'summary provenance mismatch')
    output={}
    for index,(group,expected) in enumerate(sorted(groups.items())):
        recorded=[allrows[k] for k in expected if k in allrows];usable=[r for r in recorded if r.get('status')=='completed' and r.get('usable')]
        finite_rows=[r for r in recorded if r.get('status')=='completed' and r.get('finite_estimator')]
        prior=reported.get('groups',{}).get(group,{}).get('procedure',{})
        require(prior.get('expected')==len(expected) and prior.get('recorded')==len(recorded) and prior.get('usable')==len(usable),'group denominator mismatch '+group)
        selected=finite_rows if '/fixed_' in group else usable
        for j,p in enumerate([.05,.95]):
            if not usable:continue
            calculated=estimates(usable,j)
            stored=prior.get('endpoints',{}).get(str(p),{})
            for field,actual in [('mean_error',calculated['bias']),('rmse',calculated['rmse']),('empirical_sd',calculated['empirical_sd']),('mcse_calibration_ratio',calculated['mcse_calibration_ratio'])]:
                require(finite(stored.get(field)) and math.isclose(stored[field],actual,rel_tol=1e-10,abs_tol=1e-12),'summary numeric mismatch '+group+'/'+field)
        output[group]=dict(expected=len(expected),recorded=len(recorded),usable=len(usable),unconditional_usable_rate=len(usable)/len(expected),
            analysis_scope='all finite fixed-length stationary estimates' if '/fixed_' in group else 'conditional on usable stopped outputs',
            selected=len(selected),endpoints={str(p):intervals(selected,j,1720000000+2*index+j,bootstrap) for j,p in enumerate([.05,.95])} if len(selected)>=2 and not failures else {})
    return dict(phase='exploratory',qualified=False,audit_pass=not failures,failures=failures,plan_sha256=sha,
        bootstrap_note='Independent outer-replicate percentile bootstrap; marginal approximate 95% intervals, no multiplicity correction. It cannot detect shared sampler bias outside these exact controls.',groups=output)


def main():
    p=argparse.ArgumentParser();p.add_argument('--plan',required=True);p.add_argument('--results',required=True);p.add_argument('--worker-source',required=True);p.add_argument('--out',required=True);p.add_argument('--bootstrap',type=int,default=2000);a=p.parse_args()
    value=audit(a.plan,a.results,a.worker_source,a.bootstrap)
    with Path(a.out).open('x') as handle:json.dump(value,handle,indent=2,allow_nan=False)


if __name__=='__main__':main()
