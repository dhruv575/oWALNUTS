﻿"""Static launch preparation. No scheduler launch or numerical imports."""
import argparse,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
H=1800_000_000_000;W=900_000_000_000
ROLES=('initialization_seed','sampler_seed','predictive_seed')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):
 with Path(p).open('x',encoding='utf8') as f:json.dump(v,f,indent=2)
def timing(capture,baseline_launch):
 launch=json.loads(baseline_launch.read_text())
 with (capture/'receipts.jsonl').open() as f:raw=f.readline()
 first=json.loads(raw);message=json.loads(first['raw'])
 if message.get('id')!=1:raise ValueError('First receipt must be subscription ACK')
 selection=json.loads((capture/'selection.json').read_text())
 if set(message.get('result',[]))!=set(selection['channels']):raise ValueError('ACK channels differ')
 stamp=first['receipt_monotonic_ns'];end=launch['capture_end_ns']
 if launch['command'][launch['command'].index('--capture-end-ns')+1]!=str(end):raise ValueError('Launch end mismatch')
 if Path(launch['command'][launch['command'].index('--capture')+1]).resolve()!=capture.resolve():raise ValueError('Capture path mismatch')
 if end-launch['capture_started_event']['receipt_monotonic_ns']!=172800_000_000_000:raise ValueError('48h lifecycle bound differs')
 origins=list(range(stamp+W,end-H+1,H))
 if len(origins)!=95:raise ValueError('Expected original 95-origin schedule')
 return dict(first_ack_ns=stamp,capture_end_ns=end,origins=origins,first_line_sha256=hashlib.sha256(raw.encode()).hexdigest(),launch_sha256=sha(baseline_launch),selection_sha256=sha(capture/'selection.json'))
def streams(origins,base):
 if type(base)is not int or base<0 or base+3*len(origins)>2**32:raise ValueError('Invalid uint32 seed range')
 return {str(o):{r:base+3*i+j for j,r in enumerate(ROLES)} for i,o in enumerate(origins)}
def audit(seeds,exclude=()):
 # Explicit future freeze action only, never performed by draft preparation.
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0');hits=[];inventory={};skipped=[]
 excluded={str(Path(p).resolve()) for p in exclude};wanted=set(seeds)
 for name in paths:
  if not name:continue
  p=(ROOT/name).resolve()
  if str(p) in excluded:continue
  if p.suffix.lower() not in ('.py','.json','.jsonl','.md','.toml','.yaml','.yml','.txt','.rs'):continue
  try:raw=p.read_bytes();content=raw.decode('utf8')
  except (UnicodeError,OSError) as e:skipped.append(dict(path=str(p),reason=repr(e)));continue
  inventory[str(p)]=hashlib.sha256(raw).hexdigest()
  values={int(x.replace('_','')) for x in re.findall(r'(?<![\w.])\d+(?:_\d+)*(?![\w.])',content)}
  for s in sorted(values&wanted):hits.append(dict(path=str(p),seed=s))
 return dict(status='pass' if not hits else 'collision',candidate_seeds=sorted(wanted),hits=hits,inventory=inventory,skipped=skipped,excluded=sorted(excluded),scope='Tracked UTF-8 text of declared extensions; decimal and underscored integer literals only. Derived arithmetic and untracked consumption require separate reserved-stream evidence.')
def draft(out,base):
 capture=ROOT/'target/market-receipt-route-v2/exploratory-48h-v1';launch=ROOT/'target/market-online-issuance-launch-v1/launch.json'
 t=timing(capture,launch);out.mkdir(parents=True,exist_ok=False)
 save(out/'draft.json',dict(status='draft_not_authorized',capture=str(capture),timing=t,origin_streams=streams(t['origins'],base),seed_status='proposed_not_audited_or_reserved',minimum_free_bytes=12*1024**3,maximum_lag_seconds=60,bindings=None,runtime_bindings=None,freeze_requirements=['Actual production smoke passes','Pending aggregate fixes final','Tracked-text audit plus explicit allocated-stream ledger pass','Exact Python/runtime/source hash snapshot','No running numerical campaign'],scope='95 original origins; missed origins remain explicit; separate from unchanged exact issuer'))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--seed-base',type=int,required=True);a=p.parse_args();draft(a.out,a.seed_base)
