"""Exclusive source/seed freeze only. Does not launch scheduler or sampler."""
import hashlib,importlib.metadata,json,re,shutil,subprocess,sys,zipfile
from pathlib import Path
import prepare
ROOT=prepare.ROOT;HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):
 with Path(p).open('x',encoding='utf8') as f:json.dump(x,f,indent=2)
def main():
 out=HERE/'frozen-v2';out.mkdir(exist_ok=False)
 capture=ROOT/'target/market-receipt-route-v2/exploratory-48h-v1';baseline=ROOT/'target/market-online-issuance-launch-v1/launch.json';timing=prepare.timing(capture,baseline);streams=prepare.streams(timing['origins'],994010001);wanted={v for row in streams.values() for v in row.values()}
 token=re.compile(r'(?<![\w.])\d+(?:_\d+)*(?![\w.])');scan=subprocess.run(['git','grep','-I','-l','-z','-E','-e','9_?9_?4_?0','--'],cwd=ROOT,capture_output=True)
 if scan.returncode not in (0,1):raise RuntimeError(scan.stderr.decode())
 paths={ROOT/name.decode() for name in scan.stdout.split(b'\0') if name};known=[]
 for folder in ['sv-reference-pilot-v1','sv-reference-pilot-v2','sv-fresh-dataset-comparison-v1','sv-historical-pilot-v1','sv-historical-rolling-v1','sv-online-production-smoke-v1','sv-hybrid-t32-v1','sv-live-admission-v1']:
  d=ROOT/'target'/folder
  if not d.is_dir():raise ValueError('Expected prior stream scope absent: '+folder)
  for parent in [d,*[p for p in d.iterdir() if p.is_dir() and (p.name.startswith('prepared') or p.name.startswith('seed-audit'))]]:
   for p in parent.iterdir():
    if p.is_file() and (p.suffix=='.py' or (p.suffix=='.json' and any(x in p.name for x in ('config','protocol','audit','intent','launch')))):
     paths.add(p);known.append(str(p.resolve()))
 inventory={};hits=[];errors=[]
 for p in sorted(paths):
  raw=p.read_bytes();inventory[str(p.resolve())]=hashlib.sha256(raw).hexdigest()
  try:text=raw.decode('utf-8-sig')
  except UnicodeError as exc:errors.append(dict(path=str(p),error=repr(exc)));continue
  found={int(m.group().replace('_','')) for m in token.finditer(text)}&wanted
  if found:hits.append(dict(path=str(p),seeds=sorted(found)))
 audit=dict(status='pass' if not hits and not errors else 'failed',candidate_seeds=sorted(wanted),count=len(wanted),hits=hits,errors=errors,inventory=inventory,known_untracked_scope=known,tracked_command='git grep -I -l -z -E -e 9_?9_?4_?0 -- followed by exact decimal/underscored token scan',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),scope='Tracked text plus named prior SV stream declarations; no claim of whole untracked repository completeness',excluded_prospective_sources={str(Path(__file__).resolve()):sha(__file__)})
 save(out/'seed-audit.json',audit)
 if audit['status']!='pass':raise ValueError('Seed audit failed; frozen directory preserved')
 save(out/'seed-ledger.json',dict(status='reserved_before_launch',origin_streams=streams,audit_sha256=sha(out/'seed-audit.json'),pairing='No reuse: all 95 origins times three roles distinct'))
 # Mirror the existing relative source layout so later development cannot
 # change the running issuer's imports. Tests are archived, never executed.
 mirror=out/'source-tree';mapping={}
 for folder in ('sv_online_issuance','sv_online_scoring','sv_prototype','receipt_features','live_snapshot','delayed_scoring'):
  for p in (ROOT/'STUDIES/market_uncertainty_v1'/folder).glob('*.py'):
   dest=mirror/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);mapping[str(p.resolve())]=dict(mirror=str(dest.resolve()),sha256=sha(dest))
 p=ROOT/'STUDIES/options_flow_v1/hardware_control.py';dest=mirror/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);mapping[str(p.resolve())]=dict(mirror=str(dest.resolve()),sha256=sha(dest))
 prior=json.loads((ROOT/'target/sv-fresh-dataset-comparison-v1/prepared/config-frozen.json').read_text());runtime=prior['runtime_bindings'];python=Path(sys.executable).resolve();package=Path(prior['package']).resolve()
 bindings={v['mirror']:v['sha256'] for v in mapping.values()};bindings.update(runtime);bindings[str(python)]=sha(python)
 for path,h in prior['bindings'].items():
  if 'site-packages' in path:
   if sha(path)!=h:raise ValueError('Tested dependency changed: '+path)
   bindings[path]=h
 for name in ('python.exe','python314.dll'):
  p=Path(sys.base_prefix)/name
  if p.exists():bindings[str(p.resolve())]=sha(p)
 for p in (Path(__file__),HERE/'prepare.py',baseline,capture/'selection.json'):
  bindings[str(p.resolve())]=sha(p)
 first=(capture/'receipts.jsonl').open('rb').readline();(out/'first-ack.jsonl').write_bytes(first);save(out/'timing.json',timing);save(out/'source-mapping.json',mapping)
 save(out/'runtime-versions.json',dict(python=sys.version,executable=str(python),packages={n:importlib.metadata.version(n) for n in ('numpy','scipy','numba','arviz')}))
 for p in out.iterdir():
  if p.is_file():bindings[str(p.resolve())]=sha(p)
 config=dict(status='frozen_live_sv_plan',python=str(python),package=str(package),bindings=bindings,runtime_bindings=runtime,origin_streams=streams,minimum_free_bytes=12*1024**3,maximum_lag_seconds=60,minimum_history=20,lookback=256,model='sv_both_prior_whitened',capture=str(capture.resolve()),capture_end_ns=timing['capture_end_ns'],origins_ns=timing['origins'],qualified=False)
 save(out/'config.json',config)
 output=ROOT/'target/market-sv-online-issuance-run-v1'
 if output.exists():raise ValueError('Intended scheduler output already exists')
 command=[str(python),str(mirror/'STUDIES/market_uncertainty_v1/sv_online_issuance/scheduler.py'),'--capture',str(capture.resolve()),'--out',str(output.resolve()),'--config',str((out/'config.json').resolve()),'--capture-end-ns',str(timing['capture_end_ns'])]
 save(out/'launch.json',dict(status='frozen_not_launched',command=command,config_sha256=sha(out/'config.json'),timing=timing,output=str(output.resolve()),initial_free_bytes=shutil.disk_usage(out).free,scope='95 original planned origins, missed origins retained; root launches separately'))
 with zipfile.ZipFile(out/'sources.zip','x',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(mirror.rglob('*.py')):z.write(p,str(p.relative_to(mirror)))
 for p,h in bindings.items():
  if sha(p)!=h:raise ValueError('Binding drift during freeze: '+p)
 save(out/'CHECKSUMS.json',{str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()})
 print(json.dumps(dict(status='frozen_not_launched',config_sha256=sha(out/'config.json'),origins=len(streams),streams=len(wanted),source_files=len(mapping),audit_files=len(inventory))))
if __name__=='__main__':main()
