﻿import pytest
from prepare import streams,H,W

def test_distinct_roles_and_no_dropped_missed_origins():
 origins=[W+i*H for i in range(95)];s=streams(origins,10000)
 assert list(map(int,s))==origins
 flat=[v for row in s.values() for v in row.values()]
 assert len(flat)==285 and len(set(flat))==285 and max(flat)==10284

def test_invalid_ranges():
 for b in (True,-1,2**32-2):
  with pytest.raises(ValueError):streams([W],b)
