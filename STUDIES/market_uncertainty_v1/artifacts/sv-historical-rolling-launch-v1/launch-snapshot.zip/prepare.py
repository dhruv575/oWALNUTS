"""Draft-only fixed 72-origin historical SV schedule; no sampler invocation."""
import argparse,hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SV=ROOT/'STUDIES/market_uncertainty_v1/sv_prototype'
HIST=ROOT/'STUDIES/market_uncertainty_v1/historical_evaluation'
ARMS=('neither','mean','scale','both')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def roles():
 return [dict(origin_index=i,ablation=ARMS[a],starts=993010001+4*i+a,sampler=993110001+4*i+a,predictive=993210001+4*i+a) for i in range(72) for a in [(i+j)%4 for j in range(4)]]
def audit(out):
 out=Path(out);out.mkdir(exist_ok=False)
 streams=[v[k] for v in roles() for k in ('starts','sampler','predictive')]
 assert len(set(streams))==864
 wanted=set(map(str,streams));pattern=re.compile(rb'(?<![0-9])(?:'+b'|'.join(x.encode() for x in sorted(wanted))+rb')(?![0-9])')
 scan=subprocess.run(['git','grep','-I','-l','-z','-F','-e','993','--'],cwd=ROOT,capture_output=True)
 if scan.returncode not in (0,1):raise RuntimeError(scan.stderr.decode())
 paths=scan.stdout.split(b'\0');inventory={};hits=[];skipped=[]
 for raw in paths:
  if not raw:continue
  p=ROOT/raw.decode('utf-8')
  if not p.is_file():skipped.append(dict(path=str(p),reason='tracked missing or nonregular'));continue
  data=p.read_bytes();inventory[str(p.resolve())]=hashlib.sha256(data).hexdigest()
  tokens=sorted({m.group().decode() for m in pattern.finditer(data)})
  if tokens:hits.append(dict(path=str(p.resolve()),tokens=tokens))
 result=dict(status='passed' if not hits and not skipped else 'failed',seeds=streams,hits=hits,skipped=skipped,inventory=inventory,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),command='git grep -I -l -z -F -e 993 --; exact numeric token filter on returned text files',scope='Git-tracked text files, prefix-prefilter then exact decimal tokens; binaries and untracked history excluded',preparer_sha256=sha(__file__))
 (out/'seed-audit.json').write_text(json.dumps(result,indent=2));return result
def prepare(audit_path,out):
 evidence=json.loads(Path(audit_path).read_text())
 if evidence['status']!='passed' or evidence['preparer_sha256']!=sha(__file__):raise ValueError('Passed current-source audit required')
 if evidence['seeds']!=[v[k] for v in roles() for k in ('starts','sampler','predictive')]:raise ValueError('Seed roles differ')
 for p,h in evidence['inventory'].items():
  if sha(p)!=h:raise ValueError('Tracked inventory changed: '+p)
 out=Path(out);out.mkdir(exist_ok=False)
 protocol=dict(status='draft_not_authorized_to_run',qualified=False,origins=[1790035200000+i*10800000 for i in range(72)],ablations=list(ARMS),lookback=256,minimum_history=20,rho=.9,nu=5.,chains=4,warmup=1000,tiers=[1000,2000,4000],cpus=[0,1,2,3],timeout_seconds_per_fit=1800,global_seconds=21600,disk_floor_bytes=12*1024**3,intended_fits=360,reference_ablation='both',roles=roles(),scope='Fixed retrospective descriptive rolling validation; dependent origins, no calibration qualification',seed_audit_sha256=sha(audit_path),pairing='both-flow backends share physical starts and sampler/prediction streams; alternate backend order by origin parity')
 (out/'pregeneration-intent.json').write_text(json.dumps(protocol,indent=2))
 sys.path[:0]=[str(SV),str(HIST)]
 import numpy as np
 from historical_inputs import build
 from synthetic import ILLUSTRATIVE_PRIORS
 from evaluate import verified_load
 acquisition=ROOT/'target/market-history-acquisition-v1'
 dataset=verified_load(acquisition/'september-development-v1',protocol_path=acquisition/'protocol-frozen-v1.json',collector_source=acquisition/'collector.py')
 (out/'acquisition-bindings.json').write_text(json.dumps(dataset['bindings'],indent=2))
 cells=[];admissions=[]
 for role in roles():
  i=role['origin_index'];arm=role['ablation'];origin=protocol['origins'][i]
  built=build(dataset['rows'],origin,ablation=arm,minimum_history=20,lookback=256)
  admissions.append(dict(origin_index=i,origin_ms=origin,ablation=arm,status=built['status'],reason=built.get('reason'),training_count=built.get('training_count')))
  name=f'origin{i:02d}-{arm}';path=out/(name+'.json');order=['public'] if arm!='both' else (['public','reference'] if i%2==0 else ['reference','public'])
  if built['status']=='ready':
   data=built['data'];data.update(rho=.9,nu=5.);data['y'][~data['observed']]=0.;data['x'][~data['observed']]=0.
   p,k,n=data['x'].shape[1],data['w'].shape[1],len(data['y']);pr=ILLUSTRATIVE_PRIORS
   mean=np.r_[pr.mu_mean,pr.log_sigma_mean,np.zeros(p+k+n)];sd=np.r_[pr.mu_sd,pr.log_sigma_sd,np.full(p,pr.beta_sd),np.full(k,pr.gamma_sd),np.ones(n)]
   starts=mean+.25*sd*np.random.default_rng(role['starts']).normal(size=(4,len(mean)))
   fixture=dict(data=data,priors=vars(pr),future=built['future'],starts=starts,predictive_seed=role['predictive'],admission=built,stream_roles=role)
   path.write_text(json.dumps(fixture,indent=2,allow_nan=False,default=lambda x:x.tolist()))
  for backend in order:cells.append(dict(id=name+'-'+backend,arm=backend,seed=role['sampler'],fixture=str(path.resolve()),origin_index=i,origin_ms=origin,ablation=arm,admission_status=built['status'],admission_reason=built.get('reason')))
 (out/'admission.json').write_text(json.dumps(admissions,indent=2))
 previous=ROOT/'target/sv-historical-pilot-v1/prepared/config-frozen.json'
 config=json.loads(previous.read_text());config.pop('draft_sha256',None)
 paths={Path(p) for p in config['bindings']};paths.update(SV.glob('*.py'));paths.update(HIST.glob('*.py'));paths.update(HERE.glob('*.py'));paths.update(out.glob('*.json'));paths.add(Path(audit_path));paths.update(Path(p) for p in dataset['bindings'])
 paths.update([ROOT/'target/historical-baseline-evaluation-v1/run-v1/features.json',ROOT/'target/historical-baseline-evaluation-v1/run-v1/result.json'])
 config.update(status='draft_not_authorized_to_run',cells=cells,protocol=protocol,bindings={str(p.resolve()):sha(p) for p in paths})
 (out/'config.json').write_text(json.dumps(config,indent=2))
 with zipfile.ZipFile(out/'sources.zip','x',zipfile.ZIP_DEFLATED) as z:
  for i,p in enumerate(sorted(paths)):
   if p.suffix=='.py':z.write(p,f'{i}/{p.name}')
 print(json.dumps(dict(cells=len(cells),ready=sum(x['admission_status']=='ready' for x in cells),config_sha256=sha(out/'config.json'))))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['audit','prepare']);p.add_argument('--out',required=True,type=Path);p.add_argument('--audit',type=Path);a=p.parse_args()
 if a.action=='audit':print(audit(a.out)['status'])
 else:prepare(a.audit,a.out)
