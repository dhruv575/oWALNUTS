"""Complete-denominator, post-fit historical rolling interval evaluation."""
import argparse,json,math,hashlib,time
from pathlib import Path

def finite(x):return type(x) in (int,float) and math.isfinite(x)
def score(interval,label):
 lo,hi=interval
 if not all(finite(x) for x in [lo,hi,label]) or hi<lo:raise ValueError('Invalid interval or label')
 return dict(width=hi-lo,covered=lo<=label<=hi,lower_miss=label<lo,upper_miss=label>hi,interval_score=hi-lo+20*max(lo-label,0)+20*max(label-hi,0))
def metrics(rows):
 scored=[r for r in rows if r.get('score') is not None];n=len(scored)
 return dict(intended=len(rows),usable=sum(r.get('usable',False) for r in rows),label_available=sum(r.get('label_available',False) for r in rows),scored=n,coverage=sum(r['score']['covered'] for r in scored)/n if n else None,mean_width=sum(r['score']['width'] for r in scored)/n if n else None,mean_interval_score=sum(r['score']['interval_score'] for r in scored)/n if n else None,lower_misses=sum(r['score']['lower_miss'] for r in scored),upper_misses=sum(r['score']['upper_miss'] for r in scored))
def numeric_gate(ev):
 canonical=ev['canonical']['all_parameters'];values=list(ev['functionals'].values())
 if not canonical or not values:return False
 for d in canonical+values:
  if not all(finite(d[k]) for k in ['rhat','bulk_ess','tail_ess']) or d['rhat']>1.01 or d['bulk_ess']<400 or d['tail_ess']<400:return False
 for d in values:
  lo,hi=d['interval'];mc=d['endpoint_mcse']
  if not all(finite(x) for x in [lo,hi,*mc]) or hi<=lo or len(mc)!=2 or min(mc)<0 or max(mc)/(hi-lo)>.02:return False
 return True
def validate_report_scope(report,cell,fixture):
 if report.get('arm')!=cell['arm'] or report.get('seed')!=cell['seed'] or report.get('predictive_seed')!=fixture['predictive_seed']:raise ValueError('Worker stream/backend identity differs')
 data=fixture['data'];t=len(data['y']);p=len(data['x'][0]);k=len(data['w'][0]);dimension=2+p+k+t
 expected={'mu','sigma','h_terminal','next_observed',*[f'beta_{j}' for j in range(p)],*[f'gamma_{j}' for j in range(k)]}
 attempts=report['attempts'];tiers=[a['draws'] for a in attempts]
 if not tiers or tiers!=[1000,2000,4000][:len(tiers)]:raise ValueError('Invalid retained tier prefix')
 for index,a in enumerate(attempts):
  ev=a['evaluation']
  if len(ev['canonical']['all_parameters'])!=dimension or set(ev['functionals'])!=expected:raise ValueError('Canonical/functional scope differs')
  passing=numeric_gate(ev) and a['divergences']==0
  if index<len(attempts)-1 and passing:raise ValueError('Continued past first passing tier')
 if report.get('precision_pass') is True and not (numeric_gate(attempts[-1]['evaluation']) and attempts[-1]['divergences']==0):raise ValueError('Final precision inconsistent')
def verify_execution_identity(execution,config_digest):
 if execution.get('config_sha256')!=config_digest:raise ValueError('Terminal configuration hash differs')
def analyze(cells,execution,features,baseline,load_report,load_fixture):
 ids=[c['id'] for c in cells]
 if len(ids)!=len(set(ids)):raise ValueError('Duplicate intended ID')
 records={r['id']:r for r in execution['records']}
 if len(records)!=len(execution['records']) or set(records)-set(ids):raise ValueError('Unexpected/duplicate terminal identity')
 labels={r['origin_ms']:r for r in features['rows']}
 if len(labels)!=len(features['rows']):raise ValueError('Duplicate label origin')
 ledger=[]
 for cell in cells:
  origin=cell['origin_ms'];f=labels.get(origin);label=f.get('log_bar_close_return') if f else None
  available=f is not None and f.get('label_available_ms') is not None and finite(label)
  r=records.get(cell['id']);entry=dict(id=cell['id'],origin_ms=origin,model=cell['ablation']+'-'+cell['arm'],arm=cell['arm'],ablation=cell['ablation'],controller_status=r.get('status') if r else 'unstarted',usable=False,label_available=available,score=None,cost_seconds=r.get('outer_seconds') if r else None)
  try:
   if r is None:raise ValueError('Missing intended terminal record')
   for key in ['origin_ms','origin_index','ablation','arm','fixture','seed']:
    if key in r and r[key]!=cell.get(key):raise ValueError('Terminal cell metadata differs: '+key)
   if r['status']!='terminal':entry['reason']=r.get('reason',r['status'])
   else:
    report=load_report(cell['id']);validate_report_scope(report,cell,load_fixture(cell));entry['worker_status']=report.get('status');entry['precision_pass']=report.get('precision_pass',False)
    if report.get('status')=='completed' and report.get('precision_pass') is True and r.get('returncode')==0:
     last=report['attempts'][-1];ev=last['evaluation'];value=ev['functionals']['next_observed'];interval=value['interval']
     if not numeric_gate(ev) or ev.get('precision_pass') is not True or last['divergences']!=0 or not ev['canonical']['all_finite'] or not all(v['all_finite'] for v in ev['functionals'].values()):raise ValueError('Reported gate inconsistency')
     if len(interval)!=2 or not all(finite(x) for x in interval) or interval[1]<interval[0]:raise ValueError('Invalid interval')
     entry.update(usable=True,selected_draws=last['draws'],interval=interval)
     if available:entry['score']=score(interval,label)
    else:entry['reason']=report.get('error','precision_or_worker_failure')
  except Exception as exc:entry.update(usable=False,score=None,reason=repr(exc),integrity_or_missing_failure=True)
  ledger.append(entry)
 origins=sorted({c['origin_ms'] for c in cells});base=[]
 for name in ['price_only','price_plus_flow']:
  selected=[r for r in baseline['outcomes'] if r['model']==name];rows={r['origin_ms']:r for r in selected}
  if len(rows)!=len(selected):raise ValueError('Duplicate baseline origin')
  for origin in origins:
   r=rows.get(origin);f=labels.get(origin);label=f.get('log_bar_close_return') if f else None;available=f is not None and f.get('label_available_ms') is not None and finite(label)
   row=dict(id=f'{origin}-{name}',origin_ms=origin,model=name,usable=r is not None and r['status']=='forecast',label_available=available,score=None)
   if row['usable']:
    row['interval']=r['distribution']['predictive_interval_90']
    if available:row['score']=score(row['interval'],label)
   base.append(row)
 public=[x for x in ledger if x['arm']=='public'];allrows=public+base;names=['neither-public','mean-public','scale-public','both-public','price_only','price_plus_flow'];grids={n:{x['origin_ms'] for x in allrows if x['model']==n and x['score'] is not None} for n in names};common=set.intersection(*grids.values())
 individual={n:metrics([x for x in allrows if x['model']==n]) for n in names};common_metrics={n:metrics([x for x in allrows if x['model']==n and x['origin_ms'] in common]) for n in names}
 both=[x for x in ledger if x['ablation']=='both'];runtime={}
 for arm in ['public','reference']:
  rows=[x for x in both if x['arm']==arm];known=all(finite(x['cost_seconds']) and x['cost_seconds']>=0 for x in rows);success=sum(x['usable'] for x in rows);total=sum(x['cost_seconds'] for x in rows) if known else None
  runtime[arm]=dict(intended=len(rows),usable=success,known_cost=known,all_attempted=all(x['controller_status']=='terminal' for x in rows),total_seconds=total,cost_per_usable=total/success if known and success else None)
 paired=[]
 for origin in origins:
  group=[x for x in both if x['origin_ms']==origin]
  if len(group)==2 and all(x['usable'] and finite(x['cost_seconds']) and x['cost_seconds']>0 for x in group):
   a=next(x for x in group if x['arm']=='public');b=next(x for x in group if x['arm']=='reference');paired.append(dict(origin_ms=origin,reference_over_public=b['cost_seconds']/a['cost_seconds']))
 return dict(qualified=False,intended=len(cells),ledger=ledger,baseline_ledger=base,individual=individual,common_scored_origins=sorted(common),common_grid=common_metrics,both_flow_runtime=runtime,conditional_both_pass_runtime_pairs=paired,campaign_outer_seconds=execution.get('outer_seconds'),scope='Dependent historical origins; passed-interval quality is conditional on usability. No log-density score computed for SV; no iid confidence interval or market qualification.')
def main():
 p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--features',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();start=time.perf_counter();load=lambda p:json.loads(p.read_text());c=load(a.config);e=load(a.run/'execution.json');paths=[a.config,a.run/'execution.json',a.features,a.baseline]
 if e.get('status')!='terminal':raise ValueError('Terminal campaign required')
 verify_execution_identity(e,hashlib.sha256(a.config.read_bytes()).hexdigest())
 for source in [a.features,a.baseline]:
  if c['bindings'].get(str(source.resolve()))!=hashlib.sha256(source.read_bytes()).hexdigest():raise ValueError('Unbound feature/baseline input')
 for path,h in c['bindings'].items():
  if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=h:raise ValueError('Source/input drift')
 reports={}
 for cell in c['cells']:
  fixture_path=Path(cell['fixture'])
  if fixture_path.exists():paths.append(fixture_path)
  f=a.run/cell['id']/'report.json'
  if f.exists():
   paths.append(f)
   try:reports[cell['id']]=load(f)
   except Exception as exc:reports[cell['id']]=dict(status='invalid_json',precision_pass=False,error=repr(exc))
 pins={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths};result=analyze(c['cells'],e,load(a.features),load(a.baseline),lambda i:reports[i],lambda cell:load(Path(cell['fixture'])));result.update(input_hashes=pins,analysis_seconds=time.perf_counter()-start)
 if any(hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h for p,h in pins.items()):raise ValueError('Analysis input drift')
 with a.out.open('x') as f:json.dump(result,f,indent=2,allow_nan=False)
if __name__=='__main__':main()
