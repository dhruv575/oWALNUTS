import json
from types import SimpleNamespace
import launch

def config(tmp_path):
 p=tmp_path/'config.json';p.write_text(json.dumps(dict(status='frozen_awaiting_root_launch_authorization',bindings={},package='unused',cells=[dict(id=str(i),arm='public',seed=1,fixture='unused',admission_status='ready') for i in range(2)])));return p
def test_subprocess_raise_keeps_denominator(tmp_path,monkeypatch):
 monkeypatch.setattr(launch.shutil,'disk_usage',lambda p:SimpleNamespace(free=100*1024**3))
 def fail(*a,**kw):raise OSError('launch failure')
 monkeypatch.setattr(launch.subprocess,'run',fail);out=tmp_path/'run';launch.launch(config(tmp_path),out)
 r=json.loads((out/'execution.json').read_text());assert [v['status'] for v in r['records']]==['operational_failed','unstarted'];assert r['records'][0]['outer_seconds']>0
def test_containment_failure_retains_returncode(tmp_path,monkeypatch):
 monkeypatch.setattr(launch.shutil,'disk_usage',lambda p:SimpleNamespace(free=100*1024**3))
 def run(cmd,**kw):
  from pathlib import Path
  Path(cmd[cmd.index('--record')+1]).write_text(json.dumps(dict(job_active_processes_after_cleanup=1)))
  return SimpleNamespace(returncode=0)
 monkeypatch.setattr(launch.subprocess,'run',run);out=tmp_path/'run';launch.launch(config(tmp_path),out)
 r=json.loads((out/'execution.json').read_text());assert r['records'][0]['status']=='operational_failed' and r['records'][0]['returncode']==0;assert r['records'][1]['status']=='unstarted'
def test_budget_admission_unstarted(tmp_path,monkeypatch):
 clock=iter([0.,1.,22000.,22001.,22002.]);monkeypatch.setattr(launch.time,'perf_counter',lambda:next(clock))
 monkeypatch.setattr(launch.subprocess,'run',lambda *a,**kw:(_ for _ in ()).throw(AssertionError('must not launch')))
 out=tmp_path/'run';launch.launch(config(tmp_path),out);r=json.loads((out/'execution.json').read_text());assert [v['status'] for v in r['records']]==['admission_unstarted','unstarted']
