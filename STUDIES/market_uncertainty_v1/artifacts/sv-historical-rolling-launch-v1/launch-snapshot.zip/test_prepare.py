from datetime import datetime,timezone
from prepare import roles,ARMS
def test_fixed_roles_order_and_streams():
 r=roles();assert len(r)==288
 seeds=[v[k] for v in r for k in ('starts','sampler','predictive')]
 assert len(set(seeds))==864
 for i in range(72):
  batch=r[4*i:4*i+4]
  assert [v['ablation'] for v in batch]==[ARMS[(i+j)%4] for j in range(4)]
  assert all(v['origin_index']==i for v in batch)
 assert datetime.fromtimestamp(1790035200000/1000,timezone.utc).isoformat()=='2026-09-22T00:00:00+00:00'
 assert datetime.fromtimestamp((1790035200000+71*10800000)/1000,timezone.utc).isoformat()=='2026-09-30T21:00:00+00:00'
