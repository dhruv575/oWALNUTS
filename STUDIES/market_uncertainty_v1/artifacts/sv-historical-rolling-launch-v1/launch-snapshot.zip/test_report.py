import unittest,copy
from report import analyze,score,verify_execution_identity,validate_report_scope
class Tests(unittest.TestCase):
 def fixture(self):
  cells=[dict(id=f'{a}-{b}',origin_ms=100,ablation=a,arm=b,seed=17,fixture='fixture.json') for a in ['neither','mean','scale','both'] for b in (['public','reference'] if a=='both' else ['public'])]
  execution=dict(records=[dict(id=c['id'],status='terminal',returncode=0,outer_seconds=2.) for c in cells],outer_seconds=11.)
  ev=dict(precision_pass=True,canonical=dict(all_finite=True,all_parameters=[dict(rhat=1.,bulk_ess=500.,tail_ess=500.)]*3),functionals=dict(next_observed=dict(interval=[-1.,1.],endpoint_mcse=[.01,.01],rhat=1.,bulk_ess=500.,tail_ess=500.,all_finite=True)))
  ev['functionals'].update({n:copy.deepcopy(ev['functionals']['next_observed']) for n in ['mu','sigma','h_terminal']})
  report=dict(status='completed',precision_pass=True,predictive_seed=19,seed=17,attempts=[dict(draws=1000,divergences=0,evaluation=ev)])
  features=dict(rows=[dict(origin_ms=100,log_bar_close_return=2.,label_available_ms=200)])
  baseline=dict(outcomes=[dict(origin_ms=100,model=n,status='forecast',distribution=dict(predictive_interval_90=[-2.,2.])) for n in ['price_only','price_plus_flow']])
  return cells,execution,features,baseline,{c['id']:dict(copy.deepcopy(report),arm=c['arm']) for c in cells}
 def test_full_grid_and_proper_score(self):
  c,e,f,b,r=self.fixture();v=analyze(c,e,f,b,r.__getitem__,lambda cell:dict(predictive_seed=19,data=dict(y=[0.],x=[[]],w=[[]])));self.assertEqual(v['intended'],5);self.assertEqual(v['common_scored_origins'],[100]);self.assertEqual(v['individual']['both-public']['upper_misses'],1);self.assertEqual(v['individual']['both-public']['mean_interval_score'],22.)
 def test_missing_failed_unstarted_keep_denominator(self):
  c,e,f,b,r=self.fixture();e['records'][0]['status']='unstarted';del r['mean-public'];r['both-public']['precision_pass']=False
  v=analyze(c,e,f,b,r.__getitem__,lambda cell:dict(predictive_seed=19,data=dict(y=[0.],x=[[]],w=[[]])));self.assertEqual(len(v['ledger']),5);self.assertEqual(v['common_scored_origins'],[]);self.assertEqual(v['both_flow_runtime']['public']['total_seconds'],2.);self.assertEqual(v['both_flow_runtime']['public']['usable'],0);self.assertEqual(v['conditional_both_pass_runtime_pairs'],[])
 def test_missing_label_separate_from_usable(self):
  c,e,f,b,r=self.fixture();f['rows'][0].update(log_bar_close_return=None,label_available_ms=None);v=analyze(c,e,f,b,r.__getitem__,lambda cell:dict(predictive_seed=19,data=dict(y=[0.],x=[[]],w=[[]])));self.assertEqual(v['individual']['both-public']['usable'],1);self.assertEqual(v['individual']['both-public']['scored'],0)
 def test_label_change_does_not_change_admission(self):
  c,e,f,b,r=self.fixture();a=analyze(c,e,f,b,r.__getitem__,lambda cell:dict(predictive_seed=19,data=dict(y=[0.],x=[[]],w=[[]])));f['rows'][0]['log_bar_close_return']=-20.;z=analyze(c,e,f,b,r.__getitem__,lambda cell:dict(predictive_seed=19,data=dict(y=[0.],x=[[]],w=[[]])));self.assertEqual([v['usable'] for v in a['ledger']],[v['usable'] for v in z['ledger']]);self.assertNotEqual(a['individual'],z['individual'])
 def test_duplicate_identity_rejected(self):
  c,e,f,b,r=self.fixture()
  with self.assertRaises(ValueError):analyze(c+c[:1],e,f,b,r.__getitem__,lambda cell:dict(predictive_seed=19,data=dict(y=[0.],x=[[]],w=[[]])))
 def test_wrong_configuration_rejected(self):
  with self.assertRaises(ValueError):verify_execution_identity(dict(config_sha256='wrong'),'right')
  verify_execution_identity(dict(config_sha256='right'),'right')
 def test_metadata_mismatch_is_explicit_failure(self):
  c,e,f,b,r=self.fixture();e['records'][0]['origin_ms']=999
  v=analyze(c,e,f,b,r.__getitem__,lambda cell:dict(predictive_seed=19,data=dict(y=[0.],x=[[]],w=[[]])));self.assertEqual(len(v['ledger']),5);self.assertFalse(v['ledger'][0]['usable']);self.assertTrue(v['ledger'][0]['integrity_or_missing_failure'])
 def test_duplicate_baseline_rejected(self):
  c,e,f,b,r=self.fixture();b['outcomes'].append(copy.deepcopy(b['outcomes'][0]))
  with self.assertRaises(ValueError):analyze(c,e,f,b,r.__getitem__,lambda cell:dict(predictive_seed=19,data=dict(y=[0.],x=[[]],w=[[]])))
 def test_boolean_success_does_not_override_numeric_gate(self):
  c,e,f,b,r=self.fixture();r['both-public']['attempts'][0]['evaluation']['functionals']['next_observed']['endpoint_mcse']=[.2,.2]
  v=analyze(c,e,f,b,r.__getitem__,lambda cell:dict(predictive_seed=19,data=dict(y=[0.],x=[[]],w=[[]])));self.assertFalse(next(x for x in v['ledger'] if x['id']=='both-public')['usable'])
 def test_swapped_report_identity_and_scope(self):
  for mutation in ['arm','seed','predictive_seed','dimension','functionals','tier','first_pass']:
   with self.subTest(mutation=mutation):
    c,e,f,b,r=self.fixture();x=r['both-public']
    if mutation=='arm':x['arm']='reference'
    elif mutation=='seed':x['seed']=18
    elif mutation=='predictive_seed':x['predictive_seed']=20
    elif mutation=='dimension':x['attempts'][0]['evaluation']['canonical']['all_parameters'].pop()
    elif mutation=='functionals':x['attempts'][0]['evaluation']['functionals'].pop('sigma')
    elif mutation=='tier':x['attempts'][0]['draws']=2000
    else:
     second=copy.deepcopy(x['attempts'][0]);second['draws']=2000;x['attempts'].append(second)
    v=analyze(c,e,f,b,r.__getitem__,lambda cell:dict(predictive_seed=19,data=dict(y=[0.],x=[[]],w=[[]])))
    self.assertFalse(next(a for a in v['ledger'] if a['id']=='both-public')['usable'])
if __name__=='__main__':unittest.main()
