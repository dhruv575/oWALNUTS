# Fixed rolling historical SV draft

No sampling is authorized by this draft. The fixed schedule contains 72 origins every three hours from September 22 00:00 through September 30 21:00 UTC, predicting the next half-hour traded BTC-PERPETUAL bar-close return. Historical bar opening timestamps and zero close-publication lag remain explicit assumptions, not receipt-time evidence.

Each origin has four public SV ablations (neither, mean, scale, both) and one reference both-flow fit: 360 intended outcomes. The four ablation groups rotate cyclically by origin index. The both-flow public/reference fits stay adjacent and alternate order. Their fixture, physical starts and sampler/prediction seeds are identical. Only those 72 pairs support a sampler runtime comparison; comparing all four public fits with the single reference fit would be misleading.

Each model uses 256 scheduled prior half-hour rows, at least 20 mature observed labels, native log-return units, past-training-only covariate scaling, unchanged illustrative priors, rho .9 and Student-t nu 5. Four chains have 1,000 warmup transitions and first-passing 1,000/2,000/4,000 retained tiers. All canonical-coordinate and functional health/precision gates remain unchanged.

The copied controller uses CPUs 0–3, an 1,800-second contained fit allowance, six-hour whole-run admission budget and 12 GiB disk floor. The global cap may truncate the schedule; every unstarted or no-fit row remains in the 360-outcome denominator. No automatic retry or overwrite is allowed. Roughly 40 minutes for all fits is a planning projection from the small prior pilot, not a guarantee.

The explicit role scan uses git grep on tracked text with a 993 prefix prefilter, then exact numeric tokens; it records HEAD and hashes of candidate text files. It does not claim coverage of binary, ignored or untracked historical experiments. Exact tokens are checked before generation, and changed bound files invalidate preparation. The proposed starts/sampler/prediction ranges contain 864 unique values; backend pairing intentionally reuses the both-flow role within an origin.

Report all 72 scheduled origins and per-arm availability, then compare predictive coverage, width and interval score on matching successful origins with the frozen exact baselines. Preserve failed-fit counts and full costs separately. Scores describe a dependent, retrospective historical period; this is not a calibrated-coverage qualification or a future unseen test. Features/priors/model recipe are fixed before these SV fits. No final-segment label enters the fit for an earlier origin.

Preparation stages: `prepare.py audit --out <new-audit-directory>`, followed only after review by `prepare.py prepare --audit <audit/seed-audit.json> --out <new-prepared-directory>`. A reviewed freeze and root launch decision are separate.
