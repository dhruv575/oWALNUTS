"""Verify saved actual CLI outputs; exercise one deliberate hash rejection."""
import hashlib,json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2];here=Path(__file__).parent;out=here/'collector-v2-smoke';collector=root/'target/market-receipt-route-v2/smoke-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
summary=json.loads((collector/'summary.json').read_text());expected=summary['files_sha256']['receipts.jsonl']
assert sha(collector/'receipts.jsonl')==expected
results={}
for kind in ('default','two-second'):
 result=json.loads((out/(kind+'-result.json')).read_text())
 assert result['receipts_sha256']==expected and result['collector_summary_sha256']==sha(collector/'summary.json') and result['config_sha256']==sha(out/(kind+'-config.json')) and result['source_sha256']==sha(here/'features.py')
 rows=result['rows'];features=[r['features'] for r in rows]
 results[kind]=dict(origins=len(rows),known_flow=sum(f['flow_known'] for f in features),known_zero=sum(f['flow_status']=='known_zero' for f in features),unknown_flow=sum(not f['flow_known'] for f in features),observed_trade_count=sum(f['observed_trade_count'] for f in features),mature_observable_labels=sum(r['label']['observed'] for r in rows),invalid_trade_receipts=result['invalid_trade_receipts'])
assert results['default']['origins']==0
bad=out/'tampered';bad.mkdir();(bad/'receipts.jsonl').write_bytes((collector/'receipts.jsonl').read_bytes()+b'\n')
cmd=[sys.executable,str(here/'features.py'),'--receipts',str(bad/'receipts.jsonl'),'--collector-summary',str(collector/'summary.json'),'--config',str(out/'two-second-config.json'),'--out',str(bad/'result.json')]
process=subprocess.run(cmd,capture_output=True,text=True)
assert process.returncode!=0 and 'Collector receipt binding differs' in process.stderr and not (bad/'result.json').exists()
(bad/'stderr.txt').write_text(process.stderr)
bindings={str(p):sha(p) for p in [Path(__file__),here/'features.py',here/'test_features.py',collector/'summary.json',collector/'receipts.jsonl',*out.glob('*config.json'),*out.glob('*result.json')]}
evidence=dict(passed=True,qualified=False,results=results,tamper=dict(command=cmd,returncode=process.returncode,expected_rejection=True,output_absent=True),bindings=bindings,scope='Receipt-to-feature plumbing only; two-second horizon is not a30minute market forecast or interval accuracy result.')
with (out/'verification.json').open('x') as f:json.dump(evidence,f,indent=2)
snapshot=out/'executed-source';snapshot.mkdir()
for n in ('features.py','test_features.py','verify_smoke.py'):(snapshot/n).write_bytes((here/n).read_bytes())
print(json.dumps(results))
