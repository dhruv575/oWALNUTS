﻿"""Instrument unchanged compiled target via a serialized Python diagnostic wrapper."""
import ctypes,hashlib,json,sys,time,threading,traceback
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'STUDIES/market_uncertainty_v1/sv_prototype'))
from target import Target,Priors
from adapter import compile_target
import owalnuts
BASE=ROOT/'target/sv-reference-pilot-v1'
def main():
 out=Path(__file__).parent/'result-v1';out.mkdir(exist_ok=False);f=json.loads((BASE/'fixture.json').read_text());m=Target(**f['data'],priors=Priors(**f['priors']));compiled=compile_target(m);lock=threading.Lock();first=[];calls=[0]
 signature=ctypes.CFUNCTYPE(ctypes.c_double,ctypes.c_ssize_t,ctypes.POINTER(ctypes.c_double),ctypes.POINTER(ctypes.c_double),ctypes.c_void_p)
 @signature
 def wrapped(dim,qptr,gptr,user):
  try:
   q=np.ctypeslib.as_array(qptr,shape=(dim,)).copy();v,g=compiled.value_gradient(q);np.ctypeslib.as_array(gptr,shape=(dim,))[:]=g
   with lock:
    calls[0]+=1
    if not np.isfinite(v) and not first:first.append(dict(q=q.copy(),callback_index=calls[0]))
   return v
  except BaseException:
   np.ctypeslib.as_array(gptr,shape=(dim,))[:]=np.nan;return float('nan')
 target=owalnuts.from_cfunc(ctypes.cast(wrapped,ctypes.c_void_p).value,m.dimension);tick=time.perf_counter();engine=None;report=dict(scope='Diagnostic wrapper only; same target, starts,seed6201,warmup1000,maxdraws4000,threads4. GIL wrapper changes performance only; no speed or posterior claims.',source_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),BASE/'fixture.json',ROOT/'STUDIES/market_uncertainty_v1/sv_prototype/adapter.py']})
 try:
  engine=owalnuts.start_session(target,init=np.asarray(f['starts']),chains=4,warmup=1000,max_draws=4000,seed=6201,threads=4);engine.adapt();report['status']='unexpected_adaptation_complete'
 except Exception as exc:report.update(status='reproduced_failure',error=str(exc))
 finally:
  if engine is not None:report['progress']=engine.progress();engine.close()
 report.update(seconds=time.perf_counter()-tick,calls=calls[0])
 if first:
  q=first[0].pop('q');np.save(out/'first-q.npy',q,allow_pickle=False);report['first_failure']=first[0];report['first_failure'].update(q=q.tolist(),mu=float(q[0]),log_sigma=float(q[1]),max_abs_q=float(np.max(np.abs(q))),finite=bool(np.isfinite(q).all()))
  try:
   with np.errstate(all='raise'):v,g=m.value_gradient(q)
   report['python_target']=dict(value=v,gradient_finite=bool(np.isfinite(g).all()))
  except Exception as exc:report['python_target']=dict(error=repr(exc))
  with np.errstate(all='ignore'):
   standardized=(q-np.r_[m.priors.mu_mean,m.priors.log_sigma_mean,np.zeros(m.dimension-2)])/np.r_[m.priors.mu_sd,m.priors.log_sigma_sd,np.full(m.p,m.priors.beta_sd),np.full(m.k,m.priors.gamma_sd),np.ones(m.t)]
   report['standardized_max_abs']=float(np.max(np.abs(standardized)));report['prior_quadratic_finite']=bool(np.isfinite(standardized@standardized));report['sigma_exp_finite']=bool(np.isfinite(np.exp(q[1])))
 (out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ('first_failure','source_hashes')},default=str))
if __name__=='__main__':main()
