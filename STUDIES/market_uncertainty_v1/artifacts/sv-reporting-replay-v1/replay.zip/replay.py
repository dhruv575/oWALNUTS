import sys,json,time,hashlib
from pathlib import Path
import numpy as np
S=Path('STUDIES/market_uncertainty_v1/sv_prototype').resolve();sys.path.insert(0,str(S))
from target import Target,Priors
from reporting import terminal_path,summarize
p=Path('target/sv-reference-pilot-v2');f=json.loads((p/'fixture.json').read_text());m=Target(**f['data'],priors=Priors(**f['priors']));out=[]
for d in sorted((p/'run-v1').glob('pair*')):
 if not d.is_dir():continue
 r=json.loads((d/'report.json').read_text())
 for a in r['attempts']:
  qpath=d/f"draws-{a['draws']}.npy";q=np.load(qpath,allow_pickle=False);tick=time.perf_counter();old=np.array([[m.path(v)[-1] for v in chain] for chain in q]);oldseconds=time.perf_counter()-tick;tick=time.perf_counter();new=terminal_path(q,m);newseconds=time.perf_counter()-tick
  tick=time.perf_counter();summary=summarize(q,m,f['future']);seconds=time.perf_counter()-tick
  plain=json.loads(json.dumps(summary,default=lambda x:x.tolist()));equal=plain==a['evaluation'];out.append(dict(fit=d.name,draws=a['draws'],q_sha256=hashlib.file_digest(qpath.open('rb'),'sha256').hexdigest(),terminal_exact=np.array_equal(old,new),terminal_max_difference=float(np.max(abs(old-new))),complete_summary_exact=equal,old_path_seconds=oldseconds,new_path_seconds=newseconds,new_summary_seconds=seconds,old_evaluation_seconds=a['evaluation_seconds']))
  print(out[-1],flush=True)
Path('target/sv-reporting-replay-v1/result.json').write_text(json.dumps(dict(qualified=False,rows=out),indent=2))
