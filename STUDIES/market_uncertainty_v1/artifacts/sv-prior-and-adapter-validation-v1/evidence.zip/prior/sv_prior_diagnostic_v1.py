import hashlib,json,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent.parent
source=root/'STUDIES/market_uncertainty_v1/sv_prototype'
sys.path.insert(0,str(source))
from synthetic import ABLATIONS, ILLUSTRATIVE_PRIORS, prior_predictive
out=root/'target/sv-prior-diagnostic-v1'
out.mkdir(exist_ok=False)
paths=[source/'target.py',source/'synthetic.py',Path(__file__)]
raw={str(p):p.read_bytes() for p in paths}
start=time.perf_counter()
reports=[prior_predictive(256,range(128),ablation,priors=ILLUSTRATIVE_PRIORS) for ablation in ABLATIONS]
assert all(Path(p).read_bytes()==b for p,b in raw.items())
record=dict(periods=256,seeds=list(range(128)),results=reports,seconds=time.perf_counter()-start,source_sha256={p:hashlib.sha256(b).hexdigest() for p,b in raw.items()},scope='Illustrative prior diagnostic; no acceptance threshold and no fitting or market calibration')
(out/'report.json').write_text(json.dumps(record,indent=2,allow_nan=False))
for p,b in raw.items():(out/Path(p).name).write_bytes(b)
print(json.dumps(record))
