﻿import hashlib,json,zipfile,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];out=R/'STUDIES/market_uncertainty_v1/artifacts/marked-sv-rolling-v1'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2)
c=json.loads((P/'prepared-v1/config-frozen.json').read_text());r=json.loads((P/'report-result-v1.json').read_text());e=json.loads((P/'run-v1/execution.json').read_text());assert e['status']=='terminal' and e['config_sha256']==sha(P/'prepared-v1/config-frozen.json')
for p,h in {**c['bindings'],**c['runtime_bindings'],**r['input_hashes']}.items():assert sha(p)==h,p
assert len(c['cells'])==156 and len(e['records'])==156 and len(r['ledger'])==228 and all(x['usable'] for x in r['ledger'])
for cell in c['cells']:
 hw=json.loads((P/'run-v1'/(cell['id']+'-hardware.json')).read_text());rep=json.loads((P/'run-v1'/cell['id']/'report.json').read_text())
 assert hw['returncode']==0 and hw['job_active_processes_after_cleanup']==0 and hw['realized_cpus']==[0,1,2,3] and hw['enforced_before_worker_launch'] and hw['containment']['assigned_before_worker_execution']
 runtime=rep['runtime_bindings'] if cell['arm']=='public' else rep['reference_runtime_bindings']
 for p,h in runtime.items():assert sha(p)==h and {**c['bindings'],**c['runtime_bindings']}[p]==h
out.mkdir(exist_ok=False)
raw=[dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p)) for p in (P/'run-v1').rglob('*.npy')];save(out/'external-raw-manifest.json',dict(new_fit_arrays=raw,reused_raw_scope='Prior72 noflow raw arrays remain bound in sv-historical-rolling-v1 archive; no new cost or re-sampling assigned.'))
members={}
with zipfile.ZipFile(out/'evidence.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in P.rglob('*'):
  if p.is_file() and p.suffix in ('.json','.py','.md','.zip','.log'):
   name=p.relative_to(P).as_posix();z.write(p,name);members[name]=sha(p)
with zipfile.ZipFile(out/'evidence.zip') as z:
 for n,h in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
save(out/'zip-members.json',members);save(out/'verification.json',dict(integrity_pass=True,new_intended=156,reused=72,all_usable=True,common_origins=len(r['common_scored_origins']),config_sha256=sha(P/'prepared-v1/config-frozen.json'),raw_count=len(raw),zip_members=len(members)))
(out/'.gitattributes').write_text('* -text\n');(out/'RESULTS.md').write_text('''# Marked-activity rolling development result

All156 new fits passed; all72 reused no-flow fits passed. All72 historical evaluation origins remain in the common grid. No extra fit, retry or source change was performed during this archival verification.

Mean90% interval scores (lower better): no-flow .010549783; pooled activity .010566725; marked activity .010591066. All three SV coverage rates90.2778%, with2lower and5upper misses each. Marking activity did not improve the average score on this development history. Dependent retrospective origins and zero publication-lag assumptions preclude a certified market-quality claim.

The12 predeclared matched marked-activity origins cost82.0093s public versus115.3876s reference; every pair passed. This is descriptive timing, not a qualified universal speed claim. All156new fits plus controller cost1041.779195s. Prior no-flow results were reused, not resampled; their prior campaign cost2449.989469s is reported separately and excluded from new-campaign runtime. That older campaign contained other ablations too, so its whole cost is not solely the72 reused fits.

Frozen reporter already validates report scope, gates, reuse target proof and inputs. This archive additionally rechecked all frozen/report-input/runtime hashes and all156new hardware cleanup/affinity/exit records. Full reports/configurations/fixtures/proofs/sourceZIPs/reporter are in evidence.zip; exact member hashes checked. New raw arrays remain external with hashes; numerical raw replay was not performed. Reused provenance is bound by the frozen config and prior sv-historical-rolling-v1 archive.
''',encoding='utf8');save(out/'checksums.json',{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!='checksums.json'});print(json.dumps(dict(members=len(members),raw=len(raw),verified=True)))
