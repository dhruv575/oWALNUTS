import copy,math
import pytest
from report import analyze,hardware_ok

def cohort():
 cells=[];records=[];reports={};fixtures={};features={'rows':[]};baseline={'outcomes':[]}
 for i in range(72):
  features['rows'].append(dict(origin_ms=i,label_available_ms=i+1,log_bar_close_return=0.))
  for b in ('price_only','price_plus_flow'):baseline['outcomes'].append(dict(origin_ms=i,model=b,status='forecast',distribution={'predictive_interval_90':[-1.,1.]}))
  for arm,backend in [('neither','public'),('pooled_activity','public'),('marked_activity','public')]+([('marked_activity','reference')] if i%6==0 else []):
   ident=f'{i}-{arm}-{backend}';k={'neither':0,'pooled_activity':1,'marked_activity':24}[arm];fixture=dict(data={'y':[0.]*256,'x':[[1.,0.]]*256,'w':[[0.]*k]*256,'rho':.9,'nu':5.},priors=dict(mu_mean=2*math.log(.005),mu_sd=1.,log_sigma_mean=math.log(.2),log_sigma_sd=.5,beta_sd=.002,gamma_sd=.03/math.sqrt(k) if k else .03),predictive_seed=3);fixtures[ident]=fixture
   c=dict(id=ident,origin_ms=i,origin_index=i,ablation=arm,arm=backend,fixture=ident,seed=2);cells.append(c);records.append(dict(c,status='terminal',returncode=0,outer_seconds=2. if backend=='reference' else 1.))
   stat=dict(rhat=1.,bulk_ess=1000.,tail_ess=1000.,all_finite=True)
   funcs={n:dict(stat,interval=[-1.,1.],endpoint_mcse=[.01,.01]) for n in ['mu','sigma','h_terminal','next_observed','beta_0','beta_1']+[f'gamma_{j}' for j in range(k)]}
   ev=dict(canonical=dict(all_parameters=[stat]*(260+k),all_finite=True),functionals=funcs,precision_pass=True)
   reports[ident]=dict(arm=backend,seed=2,predictive_seed=3,status='completed',precision_pass=True,attempts=[dict(draws=1000,divergences=0,evaluation=ev)])
 return cells,dict(records=records,outer_seconds=300.),features,baseline,reports,fixtures

def run(c):
 cells,e,f,b,r,x=c
 return analyze(cells,e,f,b,lambda i:r[i],lambda cell:x[cell['id']])

def test72_each_common_grid_and_only12_matched_runtime_pairs():
 r=run(cohort())
 assert all(v['intended']==72 for v in r['individual'].values())
 assert len(r['common_scored_origins'])==72
 assert r['matched_marked_runtime']['public']['intended']==12
 assert r['matched_marked_runtime']['reference']['intended']==12
 assert r['matched_marked_runtime']['public']['total_seconds']==12
 assert len(r['conditional_marked_pass_runtime_pairs'])==12
 assert all(v['reference_over_public']==2 for v in r['conditional_marked_pass_runtime_pairs'])

def test_failed_paired_fit_cost_retained_and_common_labels_match():
 c=cohort();c[4]['0-marked_activity-public']['precision_pass']=False
 r=run(c)
 assert r['individual']['marked_activity-public']['intended']==72
 assert r['individual']['marked_activity-public']['scored']==71
 assert r['matched_marked_runtime']['public']['total_seconds']==12
 assert r['matched_marked_runtime']['public']['usable']==11
 assert len(r['conditional_marked_pass_runtime_pairs'])==11
 assert len(r['common_scored_origins'])==71

def test_scope_or_identity_failure_cannot_score():
 c=cohort();c[4]['0-pooled_activity-public']['seed']=999
 r=run(c);assert r['individual']['pooled_activity-public']['scored']==71
 c=cohort();c[4]['0-pooled_activity-public']['attempts'][0]['evaluation']['functionals'].pop('gamma_0')
 assert run(c)['individual']['pooled_activity-public']['scored']==71

def test_hardware_failure_rejected():
 with pytest.raises(ValueError):hardware_ok({'returncode':0},{'returncode':0})

def test_reuse_requires_exact_bound_target_proof(tmp_path):
 import hashlib,json
 from report import validate_design
 origins=list(range(72));cells=[];old=[];proof={'status':'pass','records':[]}
 for i in origins:
  for arm in ('pooled_activity','marked_activity'):
   cells.append(dict(origin_ms=i,ablation=arm,arm='public'))
  if i%6==0:cells.append(dict(origin_ms=i,ablation='marked_activity',arm='reference'))
  f=tmp_path/f'{i}.json';f.write_text(json.dumps(dict(data={},priors={},future={})));h=hashlib.sha256(f.read_bytes()).hexdigest()
  old.append(dict(origin_ms=i,ablation='neither',arm='public',fixture=str(f)))
  proof['records'].append(dict(origin_ms=i,passed=True,equal=dict(data=True,priors=True,future=True),old_fixture=str(f),old_fixture_sha256=h,new_target=dict(data={},priors={},future={}),new_target_sha256=hashlib.sha256(json.dumps(dict(data={},priors={},future={}),sort_keys=True,separators=(',',':')).encode()).hexdigest()))
 validate_design(cells,old,proof,origins)
 proof['records'][0]['equal']['future']=False
 with pytest.raises(ValueError,match='equality'):validate_design(cells,old,proof,origins)

def test_negative_rhat_and_changed_prior_rejected():
 c=cohort();c[4]['0-pooled_activity-public']['attempts'][0]['evaluation']['canonical']['all_parameters'][0]['rhat']=-1
 assert run(c)['individual']['pooled_activity-public']['scored']==71
 c=cohort();c[5]['0-marked_activity-public']['priors']['gamma_sd']=.03
 assert run(c)['individual']['marked_activity-public']['scored']==71
