"""Prospective preparation only; no inference or freezing in this entrypoint."""
import argparse,bisect,hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];sys.path.insert(0,str(ROOT))
ARMS=('pooled_activity','marked_activity')
ORIGINS=[1790035200000+i*10800000 for i in range(72)]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):
 with Path(p).open('x',encoding='utf8') as f:json.dump(v,f,indent=2,allow_nan=False,default=lambda x:x.tolist())
def roles():
 return [dict(origin_index=i,ablation=ARMS[a],starts=996010001+2*i+a,sampler=996110001+2*i+a,predictive=996210001+2*i+a) for i in range(72) for a in [(i+j)%2 for j in range(2)]]
def backends(role):
 i=role['origin_index']
 return (['public','reference'] if (i//6)%2==0 else ['reference','public']) if role['ablation']=='marked_activity' and i%6==0 else ['public']
def audit(out):
 out=Path(out);out.mkdir(exist_ok=False);wanted={v[k] for v in roles() for k in ('starts','sampler','predictive')}
 scan=subprocess.run(['git','grep','-I','-l','-z','-E','-e','9_?9_?6','--'],cwd=ROOT,capture_output=True)
 if scan.returncode not in (0,1):raise RuntimeError(scan.stderr.decode())
 paths={ROOT/p for p in scan.stdout.decode().split('\0') if p}
 scopes=['marked-sv-pilot-v1','sv-live-launch-v1','sv-historical-rolling-v1','sv-historical-pilot-v1','sv-fresh-dataset-comparison-v1','sv-reference-pilot-v1','sv-reference-pilot-v2']
 for scope in scopes:
  folder=ROOT/'target'/scope
  paths.update(folder.glob('*.py'))
  paths.update(p for p in folder.rglob('*.json') if any(k in p.name.lower() for k in ('seed','config','protocol','ledger','intent')))
 inventory={};hits=[];errors=[]
 for p in sorted(paths):
  try:
   raw=p.read_bytes();inventory[str(p.resolve())]=hashlib.sha256(raw).hexdigest();s=raw.decode('utf-8-sig')
   found=sorted({int(x.replace('_','')) for x in re.findall(r'(?<![\w.])\d+(?:_\d+)*(?![\w.])',s)}&wanted)
   if found:hits.append(dict(path=str(p),seeds=found))
  except (OSError,UnicodeError) as exc:errors.append(dict(path=str(p),error=repr(exc)))
 result=dict(status='pass' if not hits and not errors else 'failed',seeds=sorted(wanted),hits=hits,errors=errors,inventory=inventory,head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),preparer_sha256=sha(__file__),known_untracked_scopes=scopes,scope='Tracked text prefix prefilter then exact integer tokens; named prior declaration sources/JSON. New prospective directory excluded. Not universal arithmetic provenance.')
 save(out/'seed-audit.json',result);return result

def canonical(value):return json.loads(json.dumps(value,allow_nan=False,default=lambda x:x.tolist()))
def prepare(audit_path,out):
 evidence=json.loads(Path(audit_path).read_text())
 if evidence['status']!='pass' or evidence['preparer_sha256']!=sha(__file__):raise ValueError('Current passed audit required')
 if evidence['seeds']!=sorted(v[k] for v in roles() for k in ('starts','sampler','predictive')):raise ValueError('Stream mismatch')
 for p,h in evidence['inventory'].items():
  if sha(p)!=h:raise ValueError('Audit inventory drift: '+p)
 out=Path(out);out.mkdir(exist_ok=False)
 protocol=dict(status='draft_not_authorized_to_run',origins=ORIGINS,intended_fits=156,public_models=list(ARMS),reference_model='marked_activity',reference_indices=list(range(0,72,6)),lookback=256,minimum_history=20,rho=.9,nu=5,chains=4,warmup=1000,tiers=[1000,2000,4000],cpus=[0,1,2,3],timeout_seconds_per_fit=1800,global_seconds=21600,disk_floor_bytes=12*1024**3,roles=roles(),scope='Already inspected retrospective development; dependent origins, descriptive scores only, no held-out qualification or iid confidence intervals',pairing='12 marked pairs share physical starts and sampler/prediction streams; alternating pair order; public arm order rotates each origin',quality='All72 scheduled origins; scored/common grids explicitly conditional on availability and usable fits; existing exact baselines and noflow only after canonical equivalence',seed_audit_sha256=sha(audit_path))
 save(out/'pregeneration-intent.json',protocol)
 import numpy as np
 from STUDIES.market_uncertainty_v1.marked_flow.features import build as marks
 from STUDIES.market_uncertainty_v1.marked_flow.inputs import build
 from STUDIES.market_uncertainty_v1.historical_evaluation.evaluate import verified_load
 a=ROOT/'target/market-history-acquisition-v1';data=verified_load(a/'september-development-v1',protocol_path=a/'protocol-frozen-v1.json',collector_source=a/'collector.py')
 trades=[json.loads(x) for x in (a/'september-development-v1/trades.jsonl').read_text().splitlines()];trades.sort(key=lambda x:x['timestamp']);ts=[x['timestamp'] for x in trades]
 coverage=[(x['start_ms'],x['end_ms']+1) for x in json.loads((a/'september-development-v1/completed-trade-leaves.json').read_text())]
 stamps=sorted({o-j*1800000 for o in ORIGINS for j in range(257)})
 marked={o:marks(trades[bisect.bisect_left(ts,o-900000):bisect.bisect_left(ts,o)],o,coverage_intervals=coverage) for o in stamps}
 cells=[];equivalence=[];oldpaths=[]
 def target(b):
  d=b['data'];d.update(rho=.9,nu=5.);d['x'][~d['observed']]=0;d['y'][~d['observed']]=0
  return dict(data=d,priors=b['suggested_priors'],future=b['future'])
 for i,origin in enumerate(ORIGINS):
  b=build(data['rows'],marked,origin,ablation='neither');old=ROOT/f'target/sv-historical-rolling-v1/prepared/origin{i:02d}-neither.json';oldpaths.append(old)
  previous=json.loads(old.read_text());equal={k:canonical(target(b)[k])==previous[k] for k in ('data','priors','future')} if b['status']=='ready' else {}
  equivalence.append(dict(origin_index=i,origin_ms=origin,old_fixture=str(old.resolve()),old_fixture_sha256=sha(old),equal=equal,new_target=canonical(target(b)) if b['status']=='ready' else None,new_target_sha256=hashlib.sha256(json.dumps(canonical(target(b)),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest() if b['status']=='ready' else None,passed=bool(equal) and all(equal.values())))
 save(out/'noflow-equivalence.json',dict(status='pass' if all(x['passed'] for x in equivalence) else 'failed',records=equivalence,scope='Canonical data/priors/future only; starts/seeds ignored; mismatch forbids old noflow reuse'))
 for role in roles():
  i=role['origin_index'];name=role['ablation'];b=build(data['rows'],marked,ORIGINS[i],ablation=name);path=out/f'origin{i:02d}-{name}.json'
  if b['status']=='ready':
   f=target(b);pr=f['priors'];k=b['dimensions']['K'];n=260+k
   mean=np.r_[pr['mu_mean'],pr['log_sigma_mean'],np.zeros(n-2)];sd=np.r_[pr['mu_sd'],pr['log_sigma_sd'],np.full(2,pr['beta_sd']),np.full(k,pr['gamma_sd']),np.ones(256)]
   f.update(starts=mean+.25*sd*np.random.default_rng(role['starts']).normal(size=(4,n)),predictive_seed=role['predictive'],admission=b,stream_roles=role);save(path,f)
  for backend in backends(role):cells.append(dict(id=f'origin{i:02d}-{name}-{backend}',arm=backend,seed=role['sampler'],fixture=str(path.resolve()),origin_index=i,origin_ms=ORIGINS[i],ablation=name,admission_status=b['status'],admission_reason=b.get('reason')))
 previous=ROOT/'target/marked-sv-pilot-v1/prepared/config-frozen.json';c=json.loads(previous.read_text());[c.pop(key,None) for key in ('draft_sha256','rebind_from_config_sha256','revised_draft_sha256')];c['parent_template_sha256']=sha(previous)
 paths=set((ROOT/'STUDIES/market_uncertainty_v1').rglob('*.py'));paths.update((ROOT/'STUDIES/options_flow_v1').glob('*.py'));paths.update(HERE.glob('*.py'));paths.update(out.glob('*.json'));paths.add(Path(audit_path));paths.update(oldpaths);paths.update(Path(p) for p in data['bindings']);paths.update(Path(p) for p in c['bindings'] if 'site-packages' in p or p.lower().endswith('.exe'))
 oldrun=ROOT/'target/sv-historical-rolling-v1/run-v1'
 paths.update([oldrun/'execution.json',ROOT/'target/sv-historical-rolling-v1/prepared/config-frozen.json'])
 for i in range(72):
  paths.update([oldrun/f'origin{i:02d}-neither-public/report.json',oldrun/f'origin{i:02d}-neither-public-hardware.json'])
 paths.update([ROOT/'target/historical-baseline-evaluation-v1/run-v1/features.json',ROOT/'target/historical-baseline-evaluation-v1/run-v1/result.json'])
 c.update(status='draft_not_authorized_to_run',cells=cells,protocol=protocol,noflow_equivalence=str((out/'noflow-equivalence.json').resolve()),bindings={str(p.resolve()):sha(p) for p in paths});save(out/'config.json',c)
 with zipfile.ZipFile(out/'sources.zip','x',zipfile.ZIP_DEFLATED) as z:
  mapping={}
  for index,p in enumerate(sorted(paths)):
   if p.suffix=='.py':
    name=p.relative_to(ROOT).as_posix() if p.is_relative_to(ROOT) else f'external/{index}/{p.name}'
    z.write(p,name);mapping[name]=dict(original_path=str(p),sha256=sha(p))
  z.writestr('SOURCE-MAPPING.json',json.dumps(mapping,indent=2))
 print(json.dumps(dict(config=str(out/'config.json'),cells=len(cells),noflow_equivalent=all(x['passed'] for x in equivalence))))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['audit','prepare']);p.add_argument('--out',type=Path,required=True);p.add_argument('--audit',type=Path);a=p.parse_args()
 if a.action=='audit':print(audit(a.out)['status'])
 else:prepare(a.audit,a.out)
