"""Complete-denominator, post-fit historical rolling interval evaluation."""
import argparse,json,math,hashlib,time
from pathlib import Path

def finite(x):return type(x) in (int,float) and math.isfinite(x)
def score(interval,label):
 lo,hi=interval
 if not all(finite(x) for x in [lo,hi,label]) or hi<lo:raise ValueError('Invalid interval or label')
 return dict(width=hi-lo,covered=lo<=label<=hi,lower_miss=label<lo,upper_miss=label>hi,interval_score=hi-lo+20*max(lo-label,0)+20*max(label-hi,0))
def metrics(rows):
 scored=[r for r in rows if r.get('score') is not None];n=len(scored)
 return dict(intended=len(rows),usable=sum(r.get('usable',False) for r in rows),label_available=sum(r.get('label_available',False) for r in rows),scored=n,coverage=sum(r['score']['covered'] for r in scored)/n if n else None,mean_width=sum(r['score']['width'] for r in scored)/n if n else None,mean_interval_score=sum(r['score']['interval_score'] for r in scored)/n if n else None,lower_misses=sum(r['score']['lower_miss'] for r in scored),upper_misses=sum(r['score']['upper_miss'] for r in scored))
def numeric_gate(ev):
 canonical=ev['canonical']['all_parameters'];values=list(ev['functionals'].values())
 if not canonical or not values:return False
 for d in canonical+values:
  if not all(finite(d[k]) for k in ['rhat','bulk_ess','tail_ess']) or not 0<d['rhat']<=1.01 or d['bulk_ess']<400 or d['tail_ess']<400:return False
 for d in values:
  lo,hi=d['interval'];mc=d['endpoint_mcse']
  if not all(finite(x) for x in [lo,hi,*mc]) or hi<=lo or len(mc)!=2 or min(mc)<0 or max(mc)/(hi-lo)>.02:return False
 return True
def validate_report_scope(report,cell,fixture):
 if report.get('arm')!=cell['arm'] or report.get('seed')!=cell['seed'] or report.get('predictive_seed')!=fixture['predictive_seed']:raise ValueError('Worker stream/backend identity differs')
 data=fixture['data'];t=len(data['y']);p=len(data['x'][0]);k=len(data['w'][0]);dimension=2+p+k+t
 expected_k={'neither':0,'pooled_activity':1,'marked_activity':24}[cell['ablation']]
 expected_priors=dict(mu_mean=2*math.log(.005),mu_sd=1.,log_sigma_mean=math.log(.2),log_sigma_sd=.5,beta_sd=.002,gamma_sd=.03/math.sqrt(expected_k) if expected_k else .03)
 if t!=256 or p!=2 or k!=expected_k or data.get('rho')!=.9 or data.get('nu')!=5. or fixture.get('priors')!=expected_priors:raise ValueError('Declared activity target/prior scope differs')
 expected={'mu','sigma','h_terminal','next_observed',*[f'beta_{j}' for j in range(p)],*[f'gamma_{j}' for j in range(k)]}
 attempts=report['attempts'];tiers=[a['draws'] for a in attempts]
 if not tiers or tiers!=[1000,2000,4000][:len(tiers)]:raise ValueError('Invalid retained tier prefix')
 for index,a in enumerate(attempts):
  ev=a['evaluation']
  if len(ev['canonical']['all_parameters'])!=dimension or set(ev['functionals'])!=expected:raise ValueError('Canonical/functional scope differs')
  passing=numeric_gate(ev) and a['divergences']==0
  if index<len(attempts)-1 and passing:raise ValueError('Continued past first passing tier')
 if report.get('precision_pass') is True and not (numeric_gate(attempts[-1]['evaluation']) and attempts[-1]['divergences']==0):raise ValueError('Final precision inconsistent')
def verify_execution_identity(execution,config_digest):
 if execution.get('config_sha256')!=config_digest:raise ValueError('Terminal configuration hash differs')
def analyze(cells,execution,features,baseline,load_report,load_fixture):
 ids=[c['id'] for c in cells]
 if len(ids)!=len(set(ids)):raise ValueError('Duplicate intended ID')
 records={r['id']:r for r in execution['records']}
 if len(records)!=len(execution['records']) or set(records)-set(ids):raise ValueError('Unexpected/duplicate terminal identity')
 labels={r['origin_ms']:r for r in features['rows']}
 if len(labels)!=len(features['rows']):raise ValueError('Duplicate label origin')
 ledger=[]
 for cell in cells:
  origin=cell['origin_ms'];f=labels.get(origin);label=f.get('log_bar_close_return') if f else None
  available=f is not None and f.get('label_available_ms') is not None and finite(label)
  r=records.get(cell['id']);entry=dict(id=cell['id'],origin_ms=origin,model=cell['ablation']+'-'+cell['arm'],arm=cell['arm'],ablation=cell['ablation'],controller_status=r.get('status') if r else 'unstarted',usable=False,label_available=available,score=None,cost_seconds=r.get('outer_seconds') if r else None)
  try:
   if r is None:raise ValueError('Missing intended terminal record')
   for key in ['origin_ms','origin_index','ablation','arm','fixture','seed']:
    if key in r and r[key]!=cell.get(key):raise ValueError('Terminal cell metadata differs: '+key)
   if r['status']!='terminal':entry['reason']=r.get('reason',r['status'])
   else:
    report=load_report(cell['id']);validate_report_scope(report,cell,load_fixture(cell));entry['worker_status']=report.get('status');entry['precision_pass']=report.get('precision_pass',False)
    if report.get('status')=='completed' and report.get('precision_pass') is True and r.get('returncode')==0:
     last=report['attempts'][-1];ev=last['evaluation'];value=ev['functionals']['next_observed'];interval=value['interval']
     if not numeric_gate(ev) or ev.get('precision_pass') is not True or last['divergences']!=0 or not ev['canonical']['all_finite'] or not all(v['all_finite'] for v in ev['functionals'].values()):raise ValueError('Reported gate inconsistency')
     if len(interval)!=2 or not all(finite(x) for x in interval) or interval[1]<interval[0]:raise ValueError('Invalid interval')
     entry.update(usable=True,selected_draws=last['draws'],interval=interval)
     if available:entry['score']=score(interval,label)
    else:entry['reason']=report.get('error','precision_or_worker_failure')
  except Exception as exc:entry.update(usable=False,score=None,reason=repr(exc),integrity_or_missing_failure=True)
  ledger.append(entry)
 origins=sorted({c['origin_ms'] for c in cells});base=[]
 for name in ['price_only','price_plus_flow']:
  selected=[r for r in baseline['outcomes'] if r['model']==name];rows={r['origin_ms']:r for r in selected}
  if len(rows)!=len(selected):raise ValueError('Duplicate baseline origin')
  for origin in origins:
   r=rows.get(origin);f=labels.get(origin);label=f.get('log_bar_close_return') if f else None;available=f is not None and f.get('label_available_ms') is not None and finite(label)
   row=dict(id=f'{origin}-{name}',origin_ms=origin,model=name,usable=r is not None and r['status']=='forecast',label_available=available,score=None)
   if row['usable']:
    row['interval']=r['distribution']['predictive_interval_90']
    if available:row['score']=score(row['interval'],label)
   base.append(row)
 public=[x for x in ledger if x['arm']=='public'];allrows=public+base;names=['neither-public','pooled_activity-public','marked_activity-public','price_only','price_plus_flow'];grids={n:{x['origin_ms'] for x in allrows if x['model']==n and x['score'] is not None} for n in names};common=set.intersection(*grids.values())
 individual={n:metrics([x for x in allrows if x['model']==n]) for n in names};common_metrics={n:metrics([x for x in allrows if x['model']==n and x['origin_ms'] in common]) for n in names}
 reference_origins={x['origin_ms'] for x in ledger if x['arm']=='reference' and x['ablation']=='marked_activity'}
 both=[x for x in ledger if x['ablation']=='marked_activity' and x['origin_ms'] in reference_origins];runtime={}
 for arm in ['public','reference']:
  rows=[x for x in both if x['arm']==arm];known=all(finite(x['cost_seconds']) and x['cost_seconds']>=0 for x in rows);success=sum(x['usable'] for x in rows);total=sum(x['cost_seconds'] for x in rows) if known else None
  runtime[arm]=dict(intended=len(rows),usable=success,known_cost=known,all_attempted=all(x['controller_status']=='terminal' for x in rows),total_seconds=total,cost_per_usable=total/success if known and success else None)
 paired=[]
 for origin in origins:
  group=[x for x in both if x['origin_ms']==origin]
  if len(group)==2 and all(x['usable'] and finite(x['cost_seconds']) and x['cost_seconds']>0 for x in group):
   a=next(x for x in group if x['arm']=='public');b=next(x for x in group if x['arm']=='reference');paired.append(dict(origin_ms=origin,reference_over_public=b['cost_seconds']/a['cost_seconds']))
 return dict(qualified=False,intended=len(cells),ledger=ledger,baseline_ledger=base,individual=individual,common_scored_origins=sorted(common),common_grid=common_metrics,matched_marked_runtime=runtime,conditional_marked_pass_runtime_pairs=paired,campaign_outer_seconds=execution.get('outer_seconds'),scope='Dependent historical origins; passed-interval quality conditional on usability. Reused old no-flow costs excluded from new timings; only reference-selected marked origins enter sampler comparison. No log score, iid CI or qualification.')

def validate_design(cells, old_cells, proof, origins):
 if len(origins)!=72 or origins!=sorted(set(origins)):raise ValueError('Exact72-origin design required')
 expected={(t,a,b) for t in origins for a in ('pooled_activity','marked_activity') for b in ('public',)}
 expected|={(origins[i],'marked_activity','reference') for i in range(0,72,6)}
 actual=[(c['origin_ms'],c['ablation'],c['arm']) for c in cells]
 if len(actual)!=156 or set(actual)!=expected:raise ValueError('New156-cell design differs')
 if len(old_cells)!=72 or {(c['origin_ms'],c['ablation'],c['arm']) for c in old_cells}!={(t,'neither','public') for t in origins}:raise ValueError('Old no-flow72 design differs')
 records=proof['records']
 if proof.get('status')!='pass' or len(records)!=72 or {r['origin_ms'] for r in records}!=set(origins):raise ValueError('No-flow equivalence incomplete')
 by_origin={r['origin_ms']:r for r in records}
 for c in old_cells:
  r=by_origin[c['origin_ms']]
  if r.get('passed') is not True or r.get('equal')!={'data':True,'priors':True,'future':True} or Path(r['old_fixture']).resolve()!=Path(c['fixture']).resolve():raise ValueError('No-flow target equality failed')
  if hashlib.sha256(Path(c['fixture']).read_bytes()).hexdigest()!=r['old_fixture_sha256']:raise ValueError('Old fixture equality binding differs')
  old=json.loads(Path(c['fixture']).read_text())
  if r.get('new_target')!={key:old[key] for key in ('data','priors','future')}:raise ValueError('Recomputed no-flow target equality failed')
  target_digest=hashlib.sha256(json.dumps(r['new_target'],sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
  if r.get('new_target_sha256')!=target_digest:raise ValueError('New no-flow target digest differs')

def hardware_ok(h, record):
 if h.get('returncode')!=record.get('returncode') or h.get('job_active_processes_after_cleanup')!=0 or h.get('realized_cpus')!=[0,1,2,3] or h.get('enforced_before_worker_launch') is not True or h.get('containment',{}).get('assigned_before_worker_execution') is not True:raise ValueError('Worker hardware identity/cleanup differs')

def main():
 parser=argparse.ArgumentParser()
 for name in ('config','run','features','baseline','old-config','old-run','reuse-proof','out'):parser.add_argument('--'+name,type=Path,required=True)
 a=parser.parse_args();tracked={};started=time.perf_counter()
 def read(path):
  path=Path(path).resolve();raw=path.read_bytes();tracked[str(path)]=hashlib.sha256(raw).hexdigest();return json.loads(raw)
 config=read(a.config);execution=read(a.run/'execution.json');old_config=read(a.old_config);old_execution=read(a.old_run/'execution.json');proof=read(a.reuse_proof)
 if execution.get('status')!='terminal' or old_execution.get('status')!='terminal':raise ValueError('Both executions must be terminal')
 verify_execution_identity(execution,tracked[str(a.config.resolve())]);verify_execution_identity(old_execution,tracked[str(a.old_config.resolve())])
 # Prospective config must bind reused evidence and baseline inputs, not merely paths.
 for path in (a.features,a.baseline,a.old_config,a.old_run/'execution.json',a.reuse_proof):
  key=str(path.resolve());value=hashlib.sha256(path.read_bytes()).hexdigest()
  if config['bindings'].get(key)!=value:raise ValueError('Unbound comparative input: '+key)
 for path,h in config['bindings'].items():
  if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=h:raise ValueError('Source/input drift: '+path)
 old_cells=[c for c in old_config['cells'] if c['ablation']=='neither' and c['arm']=='public']
 validate_design(config['cells'],old_cells,proof,config['protocol']['origins'])
 reports={};fixtures={};records=[]
 for run,cells,source_execution,reused in ((a.run,config['cells'],execution,False),(a.old_run,old_cells,old_execution,True)):
  index={r['id']:r for r in source_execution['records']}
  if len(index)!=len(source_execution['records']):raise ValueError('Duplicate execution IDs')
  for c in cells:
   r=dict(index[c['id']]) if c['id'] in index else dict(c,status='unstarted',outer_seconds=None)
   if reused:r['reused_historical_cost_seconds']=r.get('outer_seconds');r['outer_seconds']=None
   records.append(r)
   try:
    fixtures[c['id']]=read(c['fixture'])
    if r['status']=='terminal':
     report_path=run/c['id']/'report.json';hardware_path=run/(c['id']+'-hardware.json')
     if reused:
      for path in (report_path,hardware_path):
       if config['bindings'].get(str(path.resolve()))!=hashlib.sha256(path.read_bytes()).hexdigest():raise ValueError('Unbound reused outcome')
     hardware_ok(read(hardware_path),r);report=read(report_path)
     if report.get('status')=='completed':
      runtime=report.get('runtime_bindings') if c['arm']=='public' else report.get('reference_runtime_bindings')
      if not isinstance(runtime,dict) or not runtime:raise ValueError('Actual runtime identity missing')
      expected_runtime=old_config['runtime_bindings'] if reused else config['runtime_bindings']
      if c['arm']=='public' and runtime!=expected_runtime:raise ValueError('Public runtime differs')
      expected_bindings=old_config['bindings'] if reused else config['bindings']
      for path,h in runtime.items():
       if c['arm']=='reference' and expected_bindings.get(path)!=h:raise ValueError('Reference runtime not bound')
       if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=h:raise ValueError('Actual runtime bytes differ')
     reports[c['id']]=report
   except Exception as exc:reports[c['id']]=dict(status='invalid_or_missing',error=repr(exc),precision_pass=False)
 combined=dict(execution,records=records)
 result=analyze(config['cells']+old_cells,combined,read(a.features),read(a.baseline),lambda i:reports[i],lambda c:fixtures[c['id']])
 result.update(new_intended=156,reused_no_flow_intended=72,reused_old_campaign_outer_seconds=old_execution.get('outer_seconds'),reporting_seconds=time.perf_counter()-started)
 result['new_worker_cost_seconds']=sum(r['outer_seconds'] for r in execution['records'] if finite(r.get('outer_seconds')))
 result['new_controller_overhead_seconds']=execution['outer_seconds']-result['new_worker_cost_seconds']
 for path,h in {**config['bindings'],**tracked}.items():
  if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=h:raise ValueError('Post-analysis drift')
 result['input_hashes']=tracked
 with a.out.open('x') as f:json.dump(result,f,indent=2,allow_nan=False)

if __name__=='__main__':main()

