﻿from prepare import roles,backends,ORIGINS

def test_schedule_and_streams():
 r=roles();assert len(r)==144 and len(ORIGINS)==72
 assert len({v[k] for v in r for k in ('starts','sampler','predictive')})==432
 cells=[(v,b) for v in r for b in backends(v)]
 assert len(cells)==156
 assert [v['origin_index'] for v,b in cells if b=='reference']==list(range(0,72,6))
 assert backends(next(v for v in r if v['origin_index']==0 and v['ablation']=='marked_activity'))==['public','reference']
 assert backends(next(v for v in r if v['origin_index']==6 and v['ablation']=='marked_activity'))==['reference','public']
 assert all(ORIGINS[i+1]-ORIGINS[i]==10800000 for i in range(71))

def test_launcher_rejects_wrong_schedule_before_proof():
 import pytest
 from launch import validate_plan
 with pytest.raises(ValueError,match='156'):
  validate_plan({'cells':[]})
