"""Real CLI correctness smoke on deterministic synthetic thirty-minute rows."""
import hashlib,json,subprocess,sys
from pathlib import Path
here=Path(__file__).parent;out=here/'synthetic-cli-v1';out.mkdir()
H=1800_000_000_000
rows=[]
for i in range(30):
 rows.append(dict(features=dict(origin_receipt_ns=i*H,anchor=dict(available=True,midpoint=100+i),flow_known=True,total_amount=10+i,signed_amount=(-1)**i),label=dict(horizon_end_receipt_ns=(i+1)*H,available_at_receipt_ns=(i+1)*H,observed=True,log_midpoint_return=.001*((i%3)-1))))
fixture=out/'synthetic-features.json';fixture.write_text(json.dumps(dict(synthetic=True,scope='Deterministic interface control; not market evidence',rows=rows),indent=2))
cmd=[sys.executable,str(here/'forecast.py'),'--features',str(fixture),'--output',str(out/'forecast-result.json')]
process=subprocess.run(cmd,capture_output=True,text=True)
assert process.returncode==0,process.stderr
result=json.loads((out/'forecast-result.json').read_text());hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert result['provenance']['features_sha256']==hashfile(fixture) and result['provenance']['source_sha256']==hashfile(here/'forecast.py')
assert len(result['outcomes'])==60
counts={s:sum(r['status']==s for r in result['outcomes']) for s in ('forecast','no_forecast')}
assert counts==dict(forecast=18,no_forecast=42)
assert any(r.get('reason')=='insufficient_mature_history' for r in result['outcomes'])
assert all(r['training_count']>=20 for r in result['outcomes'] if r['status']=='forecast')
evidence=dict(passed=True,qualified=False,synthetic_only=True,command=cmd,returncode=process.returncode,counts=counts,bindings={str(p):hashfile(p) for p in [Path(__file__),here/'forecast.py',here/'test_forecast.py',fixture,out/'forecast-result.json']})
(out/'validation.json').write_text(json.dumps(evidence,indent=2));snap=out/'executed-source';snap.mkdir()
for name in ('forecast.py','test_forecast.py','smoke_cli.py'):(snap/name).write_bytes((here/name).read_bytes())
print(json.dumps(counts))
