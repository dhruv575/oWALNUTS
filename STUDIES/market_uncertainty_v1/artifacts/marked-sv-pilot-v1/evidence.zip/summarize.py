﻿import hashlib,importlib.util,json,math,zipfile,time
from pathlib import Path
P=Path(__file__).resolve().parent;ROOT=P.parents[1];run=P/'run-v1';out=ROOT/'STUDIES/market_uncertainty_v1/artifacts/marked-sv-pilot-v1'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False)
cpath=P/'prepared/config-frozen.json';c=json.loads(cpath.read_text());e=json.loads((run/'execution.json').read_text());assert e['status']=='terminal' and e['config_sha256']==sha(cpath);assert c['draft_sha256']==sha(P/'prepared/config.json')
for f,h in {**c['bindings'],**c['runtime_bindings']}.items():assert sha(Path(f))==h,f
spec=importlib.util.spec_from_file_location('scope_checker',ROOT/'target/sv-historical-rolling-v1/report.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
records={r['id']:r for r in e['records']};assert len(records)==6;summary=[]
for cell in c['cells']:
 rec=records[cell['id']];rep=json.loads((run/cell['id']/'report.json').read_text());fixture=json.loads(Path(cell['fixture']).read_text());hw=json.loads((run/(cell['id']+'-hardware.json')).read_text());m.validate_report_scope(rep,cell,fixture)
 assert rec['status']=='terminal' and rec['returncode']==0 and rep['status']=='completed' and rep['precision_pass']
 assert rep['physical_initial_positions']==fixture['starts']
 assert hw['returncode']==0 and hw['job_active_processes_after_cleanup']==0 and hw['realized_cpus']==[0,1,2,3] and hw['enforced_before_worker_launch'] and hw['containment']['assigned_before_worker_execution']
 runtime=rep['runtime_bindings'] if cell['arm']=='public' else rep['reference_runtime_bindings']
 for f,h in runtime.items():assert sha(Path(f))==h and h==({**c['bindings'],**c['runtime_bindings']})[f]
 for a in rep['attempts']:
  for d in a['evaluation']['canonical']['all_parameters']+list(a['evaluation']['functionals'].values()):assert all(type(d[k])in(int,float) and math.isfinite(d[k]) for k in ('rhat','bulk_ess','tail_ess')) and d['rhat']>0
 last=rep['attempts'][-1];assert m.numeric_gate(last['evaluation']) and last['divergences']==0
 summary.append(dict(id=cell['id'],draws=last['draws'],outer_seconds=rec['outer_seconds'],interval=last['evaluation']['functionals']['next_observed']['interval'],endpoint_mcse=last['evaluation']['functionals']['next_observed']['endpoint_mcse']))
for i in range(0,6,2):assert c['cells'][i]['fixture']==c['cells'][i+1]['fixture']
agreement=[]
for i in range(0,6,2):
 a,b=summary[i:i+2];agreement.append(dict(pair=[a['id'],b['id']],endpoint_difference=[abs(x-y) for x,y in zip(a['interval'],b['interval'])],combined_mcse_units=[abs(x-y)/math.hypot(s,t) for x,y,s,t in zip(a['interval'],b['interval'],a['endpoint_mcse'],b['endpoint_mcse'])]))
result=dict(integrity_pass=True,intended=6,usable=6,cells=summary,agreement=agreement,outer_seconds=e['outer_seconds'],config_sha256=sha(cpath),current_draft_sha256=c['draft_sha256'],scope='Single validation origin computational development; endpoint agreement descriptive, shared predictive seeds; no model-selection/quality claim. Older inherited rebind fields are historical metadata, not current lineage.')
save(P/'summary.json',result);out.mkdir(exist_ok=False)
raw=[dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=sha(p)) for p in run.rglob('*.npy')];save(out/'external-raw-manifest.json',raw)
members={}
with zipfile.ZipFile(out/'evidence.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in P.rglob('*'):
  if p.is_file() and p.suffix in ('.json','.py','.md','.zip','.log'):
   name=p.relative_to(P).as_posix();data=p.read_bytes();z.writestr(name,data);members[name]=hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(out/'evidence.zip') as z:
 for n,h in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==h
save(out/'zip-members.json',members);save(out/'summary.json',result);(out/'.gitattributes').write_text('* -text\n')
(out/'README.md').write_text('All six intended fits passed full production gates. Source/runtime/hardware/paired-start/current-draft identity checks passed. Full reports, fixtures, configs, sourceZIPs, logs and preparation failure/recovery retained in evidence.zip. Raw arrays stay external, integrity hashes recorded; no numerical raw-array replay performed. Config inherited older rebind lineage fields from a prior template: they are not this campaign lineage. Authoritative current config and draft hashes are in summary.json. No market-quality/model-selection claim from this single origin.\n')
save(out/'checksums.json',{p.name:sha(p) for p in out.iterdir() if p.is_file() and p.name!='checksums.json'})
print(json.dumps(result))
