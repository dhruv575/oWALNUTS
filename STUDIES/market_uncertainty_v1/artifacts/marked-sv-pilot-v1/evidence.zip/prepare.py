﻿"""Prepare the fixed marked-activity pilot; never launches inference."""
import bisect,hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];sys.path.insert(0,str(ROOT))
SEEDS=list(range(995901,995910));ORIGIN=1789430400000
ARMS=('neither','pooled_activity','marked_activity')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False,default=lambda a:a.tolist())
def audit():
 names=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0');paths={ROOT/n for n in names if n and Path(n).suffix in ('.py','.json','.md','.rs','.toml','.txt')}
 predicates=('config','plan','protocol','seed','intent','launch','streams','reservation')
 paths.update(p for p in (ROOT/'target').rglob('*.json') if any(x in p.name.lower() for x in predicates) and HERE not in p.parents)
 inventory={};hits=[];skips=[]
 for p in sorted(paths):
  try:
   raw=p.read_bytes()
   if len(raw)>8*1024**2:skips.append(dict(path=str(p),reason='over8MiB',sha256=hashlib.sha256(raw).hexdigest()));continue
   s=raw.decode('utf8')
  except (UnicodeError,OSError) as e:skips.append(dict(path=str(p),reason=repr(e)));continue
  inventory[str(p.resolve())]=hashlib.sha256(raw).hexdigest()
  for token in re.findall(r'(?<![\w.])\d+(?:_\d+)*(?![\w.])',s):
   if int(token.replace('_','')) in SEEDS:hits.append(dict(path=str(p),seed=int(token.replace('_',''))))
 result=dict(seeds=SEEDS,hits=hits,inventory=inventory,skipped=skips,scope='Tracked source/text + target JSON names containing config/plan/protocol/seed/intent/launch/streams/reservation;8MiB UTF8 cap; exact decimal/underscored literals, not universal arithmetic provenance; this new proposal directory excluded. Live994 ledger included through config/plan files.')
 save(HERE/'seed-audit.json',result)
 if hits:raise ValueError('Seed collision: review required')
 return result

def main():
 audit()
 import numpy as np
 from STUDIES.market_uncertainty_v1.marked_flow.features import build as marks
 from STUDIES.market_uncertainty_v1.marked_flow.inputs import build
 from STUDIES.market_uncertainty_v1.historical_evaluation.evaluate import verified_load
 out=HERE/'prepared';out.mkdir(exist_ok=False);a=ROOT/'target/market-history-acquisition-v1'
 data=verified_load(a/'september-development-v1',protocol_path=a/'protocol-frozen-v1.json',collector_source=a/'collector.py')
 trades=[json.loads(x) for x in (a/'september-development-v1/trades.jsonl').read_text().splitlines()];trades.sort(key=lambda x:x['timestamp']);ts=[x['timestamp'] for x in trades]
 coverage=[(x['start_ms'],x['end_ms']+1) for x in json.loads((a/'september-development-v1/completed-trade-leaves.json').read_text())]
 origins=[ORIGIN-i*1800000 for i in range(256,-1,-1)]
 marked={o:marks(trades[bisect.bisect_left(ts,o-900000):bisect.bisect_left(ts,o)],o,coverage_intervals=coverage) for o in origins}
 cells=[]
 for i,name in enumerate(ARMS):
  b=build(data['rows'],marked,ORIGIN,ablation=name,minimum_history=20)
  if b['status']!='ready':save(out/(name+'-admission.json'),b);raise ValueError('Admission failed')
  d=b['data'];d.update(rho=.9,nu=5.);d['x'][~d['observed']]=0;d['y'][~d['observed']]=0
  pr=b['suggested_priors'];p,k,t=d['x'].shape[1],d['w'].shape[1],len(d['y'])
  mean=np.r_[pr['mu_mean'],pr['log_sigma_mean'],np.zeros(p+k+t)];sd=np.r_[pr['mu_sd'],pr['log_sigma_sd'],np.full(p,pr['beta_sd']),np.full(k,pr['gamma_sd']),np.ones(t)]
  role=dict(initialization_seed=SEEDS[i],sampler_seed=SEEDS[i+3],predictive_seed=SEEDS[i+6])
  fixture=dict(data=d,priors=pr,starts=mean+.25*sd*np.random.default_rng(role['initialization_seed']).normal(size=(4,len(mean))),future=b['future'],predictive_seed=role['predictive_seed'],admission=b,stream_roles=role)
  path=out/(name+'.json');save(path,fixture)
  for arm in (['public','reference'] if i%2==0 else ['reference','public']):cells.append(dict(id=name+'-'+arm,arm=arm,seed=role['sampler_seed'],fixture=str(path.resolve())))
 previous=ROOT/'target/sv-historical-rolling-v1/prepared/config-frozen.json';c=json.loads(previous.read_text())
 paths=set((ROOT/'STUDIES/market_uncertainty_v1').rglob('*.py'));paths.update((ROOT/'STUDIES/options_flow_v1').glob('*.py'));paths.update(HERE.glob('*.py'));paths.update(out.glob('*.json'));paths.add(HERE/'seed-audit.json');paths.update(Path(p) for p in data['bindings'])
 # Preserve executable/runtime-library identities from previously validated config.
 paths.update(Path(p) for p in c['bindings'] if 'site-packages' in p or p.lower().endswith('.exe'))
 c.update(status='draft_not_authorized_to_run',cells=cells,bindings={str(p.resolve()):sha(p) for p in paths},protocol=dict(origin_ms=ORIGIN,models=ARMS,lookback=256,chains=4,warmup=1000,tiers=[1000,2000,4000],gamma_prior='.03/sqrt(K) for K>0',scope='Single-origin computational development; no forecast quality/model selection claim'))
 save(out/'config.json',c)
 with zipfile.ZipFile(out/'sources.zip','x',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(paths):
   if p.suffix=='.py':z.write(p,p.relative_to(ROOT).as_posix())
 print(json.dumps(dict(config=str(out/'config.json'),sha256=sha(out/'config.json'),cells=len(cells))))
if __name__=='__main__':main()
